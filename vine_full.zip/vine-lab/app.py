"""
VINE LAB · Тестовый сервер с LFI-уязвимостями разной сложности.

Уровни:
  /basic        — простой include без защиты
  /filtered     — фильтр str_replace('../')  (нерекурсивный)
  /encoded      — фильтр на ../  но принимает URL-encoded
  /prefix       — добавляет префикс lang_ к параметру
  /extension    — добавляет .php к параметру
  /approved     — только пути начинающиеся с ./pages/
  /second-order — second-order LFI через имя пользователя
  /admin        — скрытая страница с флагом (не уязвима напрямую)
"""

import os
import re
import json
import logging
from pathlib import Path
from functools import wraps

from flask import (
    Flask, request, render_template_string,
    redirect, url_for, session, abort, make_response
)

app = Flask(__name__)
app.secret_key = "vine-lab-secret-do-not-use-in-prod"

BASE_DIR  = Path(__file__).parent
PAGES_DIR = BASE_DIR / "pages"
USERS_DB  = BASE_DIR / "users" / "users.json"

# ── Логи (для log poisoning) ─────────────────────────────────────────────────
log_path = BASE_DIR / "logs" / "access.log"
log_path.parent.mkdir(exist_ok=True)
file_handler = logging.FileHandler(log_path)
file_handler.setLevel(logging.INFO)
app.logger.addHandler(file_handler)
app.logger.setLevel(logging.INFO)


# ── HTML-обёртка ─────────────────────────────────────────────────────────────

def page(title: str, body: str, level: str = "", hint: str = "") -> str:
    hint_html = f"""
    <div class="hint">
      <span class="hint-label">◈ подсказка</span>
      {hint}
    </div>""" if hint else ""

    level_html = f'<span class="level">{level}</span>' if level else ""

    return render_template_string("""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>VINE LAB · {{ title }}</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{background:#0d0d0d;color:#e8dfc8;font-family:'Courier New',monospace;font-size:13px;line-height:1.7}
    .topbar{background:#111;border-bottom:1px solid #2a2418;padding:10px 24px;display:flex;align-items:center;gap:16px}
    .logo{color:#c8a45a;font-size:14px;letter-spacing:3px}
    .nav{display:flex;gap:2px;margin-left:auto}
    .nav a{color:#6b5a30;text-decoration:none;padding:4px 10px;font-size:11px;letter-spacing:1px;border:1px solid transparent}
    .nav a:hover{color:#c8a45a;border-color:#2a2418}
    .nav a.active{color:#c8a45a;border-color:#6b5a30}
    .container{max-width:900px;margin:32px auto;padding:0 24px}
    h1{color:#c8a45a;font-size:16px;letter-spacing:2px;margin-bottom:4px;font-weight:normal}
    .level{font-size:10px;letter-spacing:2px;color:#6b5a30;display:inline-block;margin-bottom:20px;border:1px solid #2a2418;padding:2px 8px}
    .card{background:#111;border:1px solid #2a2418;padding:20px 24px;margin-bottom:16px}
    .card h2{font-size:12px;letter-spacing:2px;color:#6b5a30;margin-bottom:12px;font-weight:normal}
    pre{background:#0a0a0a;border:1px solid #1a1a1a;padding:12px;overflow-x:auto;color:#7a6a4a;font-size:12px;margin:8px 0}
    .file-content{background:#0a0a0a;border:1px solid #1a1a1a;border-left:2px solid #c8a45a;padding:12px;white-space:pre-wrap;word-break:break-all;color:#e8dfc8;font-size:12px;max-height:400px;overflow-y:auto}
    .error{color:#8b3a2a;padding:8px 0}
    .hint{background:#0a0a00;border:1px solid #2a2010;border-left:2px solid #6b5a30;padding:12px 16px;margin-top:16px;font-size:11px;color:#6b5a30}
    .hint-label{color:#3a3010;letter-spacing:2px;font-size:10px;display:block;margin-bottom:6px}
    input[type=text]{background:#1a1a1a;border:1px solid #2a2418;color:#e8dfc8;font-family:'Courier New',monospace;font-size:12px;padding:6px 10px;width:100%}
    input[type=text]:focus{outline:none;border-color:#6b5a30}
    button{background:#1a1400;border:1px solid #6b5a30;color:#c8a45a;font-family:'Courier New',monospace;font-size:11px;padding:7px 18px;cursor:pointer;letter-spacing:2px;margin-top:8px}
    button:hover{background:#2a2010}
    .sep{color:#2a2418;margin:0 6px}
    .flag{color:#c8a45a;font-size:14px;letter-spacing:2px;padding:12px;background:#1a1400;border:1px solid #6b5a30;display:inline-block;margin:8px 0}
    .levels{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:8px}
    .level-card{background:#111;border:1px solid #2a2418;padding:14px;text-decoration:none;display:block}
    .level-card:hover{border-color:#6b5a30}
    .level-card .lc-title{color:#c8a45a;font-size:12px;letter-spacing:1px;margin-bottom:4px}
    .level-card .lc-desc{color:#6b5a30;font-size:11px}
    .level-card .lc-badge{font-size:9px;letter-spacing:2px;color:#3a3020;border:1px solid #2a2010;padding:1px 6px;float:right}
    table{width:100%;border-collapse:collapse}
    td,th{padding:6px 10px;border-bottom:1px solid #1a1a1a;text-align:left}
    th{color:#6b5a30;font-size:10px;letter-spacing:2px;font-weight:normal}
    td{color:#e8dfc8}
    form .row{display:flex;gap:8px;align-items:flex-end}
    form .row input{flex:1}
  </style>
</head>
<body>
<div class="topbar">
  <span class="logo">✦ VINE LAB</span>
  <span style="color:#2a2418">·</span>
  <span style="color:#6b5a30;font-size:11px;letter-spacing:1px">lfi vulnerability lab</span>
  <nav class="nav">
    <a href="/">index</a>
    <a href="/basic">basic</a>
    <a href="/filtered">filtered</a>
    <a href="/encoded">encoded</a>
    <a href="/prefix">prefix</a>
    <a href="/extension">extension</a>
    <a href="/approved">approved</a>
    <a href="/second-order">2nd-order</a>
  </nav>
</div>
<div class="container">
  <h1>{{ title }}</h1>
  {{ level_html | safe }}
  {{ body | safe }}
  {{ hint_html | safe }}
</div>
</body>
</html>""", title=title, body=body, hint_html=hint_html, level_html=level_html)


# ── INDEX ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    body = """
    <div class="card">
      <h2>◈ ДОБРО ПОЖАЛОВАТЬ В VINE LAB</h2>
      <p style="color:#7a6a4a;margin-bottom:16px">
        Тестовый полигон с LFI-уязвимостями разной сложности.<br>
        Используй Vine для автоматического сканирования или тестируй вручную.
      </p>
      <div class="levels">
        <a href="/basic" class="level-card">
          <span class="lc-badge">EASY</span>
          <div class="lc-title">basic</div>
          <div class="lc-desc">include без какой-либо защиты</div>
        </a>
        <a href="/filtered" class="level-card">
          <span class="lc-badge">EASY</span>
          <div class="lc-title">filtered</div>
          <div class="lc-desc">нерекурсивный str_replace</div>
        </a>
        <a href="/encoded" class="level-card">
          <span class="lc-badge">MEDIUM</span>
          <div class="lc-title">encoded</div>
          <div class="lc-desc">фильтр ../ → URL encoding bypass</div>
        </a>
        <a href="/prefix" class="level-card">
          <span class="lc-badge">MEDIUM</span>
          <div class="lc-title">prefix</div>
          <div class="lc-desc">добавляет lang_ перед значением</div>
        </a>
        <a href="/extension" class="level-card">
          <span class="lc-badge">MEDIUM</span>
          <div class="lc-title">extension</div>
          <div class="lc-desc">добавляет .html к параметру</div>
        </a>
        <a href="/approved" class="level-card">
          <span class="lc-badge">HARD</span>
          <div class="lc-title">approved path</div>
          <div class="lc-desc">regex: только ./pages/...</div>
        </a>
        <a href="/second-order" class="level-card">
          <span class="lc-badge">HARD</span>
          <div class="lc-title">second-order</div>
          <div class="lc-desc">LFI через имя пользователя в БД</div>
        </a>
      </div>
    </div>
    <div class="card">
      <h2>◈ ФЛАГИ</h2>
      <table>
        <tr><th>файл</th><th>содержимое</th><th>уровень</th></tr>
        <tr><td>pages/flag.txt</td><td style="color:#c8a45a">HTB{v1n3_s33s_4ll_p4ths}</td><td>basic–approved</td></tr>
        <tr><td>secret/admin.txt</td><td style="color:#c8a45a">HTB{s3c0nd_0rd3r_pwn3d}</td><td>second-order</td></tr>
        <tr><td>logs/access.log</td><td style="color:#6b5a30">лог для log poisoning</td><td>advanced</td></tr>
      </table>
    </div>
    <div class="card">
      <h2>◈ VINE · БЫСТРЫЙ СТАРТ</h2>
      <pre>python main.py

# В приложении:
# URL:    http://127.0.0.1:5000/basic?page=home
# Params: page
# OS:     linux</pre>
    </div>
    """
    return page("VINE LAB · LFI Playground", body)


# ── LEVEL 1 · BASIC ──────────────────────────────────────────────────────────

@app.route("/basic")
def basic():
    """include() без всякой защиты."""
    lang = request.args.get("page", "home")

    # Логируем User-Agent (для log poisoning демонстрации)
    app.logger.info(f'GET /basic?page={lang} "{request.headers.get("User-Agent", "-")}"')

    content = _read_file_unsafe(lang, base=BASE_DIR / "pages")

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>page = request.args.get('page', 'home')
content = open(f'pages/{{page}}').read()  # ← нет проверки!</pre>
    </div>
    <div class="card">
      <h2>◈ РЕЗУЛЬТАТ · pages/{lang}</h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{lang}" placeholder="home">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Basic LFI", body,
        level="LEVEL 1 · EASY",
        hint="Параметр <code>page</code> передаётся напрямую в open(). "
             "Попробуй: <code>?page=../pages/flag.txt</code> или "
             "<code>?page=../secret/admin.txt</code>"
    )


# ── LEVEL 2 · FILTERED ───────────────────────────────────────────────────────

@app.route("/filtered")
def filtered():
    """str_replace('../', '') — нерекурсивный."""
    lang = request.args.get("page", "home")
    sanitized = lang.replace("../", "")   # ← нерекурсивно!

    content = _read_file_unsafe(sanitized, base=BASE_DIR / "pages")

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>lang = request.args.get('page', 'home')
sanitized = lang.replace('../', '')   # ← нерекурсивно!
content = open(f'pages/{{sanitized}}').read()</pre>
    </div>
    <div class="card">
      <h2>◈ ПОСЛЕ ФИЛЬТРА · <span style="color:#8b3a2a">{sanitized}</span></h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{lang}" placeholder="....//....//secret/admin.txt">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Filtered LFI", body,
        level="LEVEL 2 · EASY",
        hint="<code>replace('../', '')</code> выполняется один раз. "
             "Используй <code>....//</code> — после удаления <code>../</code> останется <code>../</code>. "
             "Пример: <code>?page=....//....//secret/admin.txt</code>"
    )


# ── LEVEL 3 · ENCODED ────────────────────────────────────────────────────────

@app.route("/encoded")
def encoded():
    """Фильтрует ../ но не декодирует URL перед проверкой."""
    import urllib.parse
    # Читаем RAW query string — parse_qs декодирует, поэтому парсим вручную
    raw_qs = request.query_string.decode("utf-8", errors="replace")
    # Извлекаем значение page без URL-декодирования
    lang_raw = "home"
    for part in raw_qs.split("&"):
        if part.startswith("page="):
            lang_raw = part[5:]   # всё после "page=" — сырое, не декодированное
            break
    lang = lang_raw

    # Фильтр проверяет СЫРУЮ строку (до декодирования)
    # Если ../ есть напрямую — блокируем. Если закодировано (%2e%2e%2f) — пропускаем.
    if "../" in lang_raw or "..\\" in lang_raw:
        content = '<div class="error">⛔ Illegal path detected: ../ is not allowed</div>'
        safe = lang_raw
    else:
        safe = urllib.parse.unquote(lang_raw)   # ← декодируем ПОСЛЕ проверки
        content = _read_file_unsafe(safe, base=BASE_DIR / "pages")

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>lang = request.args.get('page', 'home')
if '../' in lang:                      # ← проверяем сырой ввод
    return 'Illegal path!'
safe = urllib.parse.unquote(lang)      # ← декодируем ПОСЛЕ проверки
content = open(f'pages/{{safe}}').read()</pre>
    </div>
    <div class="card">
      <h2>◈ RAW INPUT · <span style="color:#8b3a2a">{lang}</span></h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{lang}" placeholder="%2e%2e%2fsecret%2fadmin.txt">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Encoded LFI", body,
        level="LEVEL 3 · MEDIUM",
        hint="Фильтр проверяет <code>../</code> в сырой строке. "
             "Закодируй: <code>.</code>→<code>%2e</code>, <code>/</code>→<code>%2f</code>. "
             "Пример: <code>?page=%2e%2e%2f%2e%2e%2fsecret%2fadmin.txt</code>"
    )


# ── LEVEL 4 · PREFIX ─────────────────────────────────────────────────────────

@app.route("/prefix")
def prefix():
    """Добавляет lang_ перед параметром."""
    lang = request.args.get("lang", "en")
    path = "lang_" + lang   # ← prefix

    content = _read_file_unsafe(path, base=BASE_DIR / "pages")

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>lang = request.args.get('lang', 'en')
path = 'lang_' + lang          # ← добавляет префикс
content = open(f'pages/{{path}}').read()</pre>
    </div>
    <div class="card">
      <h2>◈ ИТОГОВЫЙ ПУТЬ · <span style="color:#8b3a2a">pages/{path}</span></h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="lang" value="{lang}" placeholder="/../../../../secret/admin.txt">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Prefix LFI", body,
        level="LEVEL 4 · MEDIUM",
        hint="Путь = <code>lang_</code> + ввод. Добавь <code>/</code> перед traversal: "
             "<code>?lang=/../../../../secret/admin.txt</code>. "
             "Результат: <code>lang_/../../../../secret/admin.txt</code> — traversal работает."
    )


# ── LEVEL 5 · EXTENSION ──────────────────────────────────────────────────────

@app.route("/extension")
def extension():
    """Добавляет .html к параметру."""
    lang = request.args.get("page", "home")
    path = lang + ".html"   # ← добавляет расширение

    content = _read_file_unsafe(path, base=BASE_DIR / "pages")

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>lang = request.args.get('page', 'home')
path = lang + '.html'          # ← добавляет расширение
content = open(f'pages/{{path}}').read()</pre>
    </div>
    <div class="card">
      <h2>◈ ИТОГОВЫЙ ПУТЬ · <span style="color:#8b3a2a">pages/{path}</span></h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{lang}" placeholder="../secret/admin.txt\x00">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Extension LFI", body,
        level="LEVEL 5 · MEDIUM",
        hint="К пути добавляется <code>.html</code>, поэтому <code>/etc/passwd</code> "
             "ищется как <code>/etc/passwd.html</code>. "
             "На Python 3 null-byte не работает — попробуй найти файлы с расширением <code>.html</code> "
             "или используй это для чтения исходников: <code>?page=../app</code> → <code>pages/../app.html</code>"
    )


# ── LEVEL 6 · APPROVED PATH ──────────────────────────────────────────────────

@app.route("/approved")
def approved():
    """Regex: путь должен начинаться с ./pages/"""
    lang = request.args.get("page", "./pages/home.txt")

    if not re.match(r'^\./pages/.+', lang):
        content = '<div class="error">⛔ Illegal path: must start with ./pages/</div>'
        safe = lang
    else:
        safe = lang
        content = _read_file_unsafe_raw(safe, base=BASE_DIR)

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>lang = request.args.get('page', './pages/home.txt')
if not re.match(r'^\\./pages/.+', lang):
    return 'Illegal path!'
content = open(lang).read()    # ← relative to BASE_DIR</pre>
    </div>
    <div class="card">
      <h2>◈ ПУТЬ · <span style="color:#8b3a2a">{safe}</span></h2>
      {content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{lang}" placeholder="./pages/../../../../secret/admin.txt">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Approved Path LFI", body,
        level="LEVEL 6 · HARD",
        hint="Regex требует начала с <code>./pages/</code>. "
             "Начни с разрешённого пути, затем выйди: "
             "<code>?page=./pages/../../../../secret/admin.txt</code>"
    )


# ── LEVEL 7 · SECOND-ORDER ───────────────────────────────────────────────────

@app.route("/second-order", methods=["GET"])
def second_order():
    """Регистрация с LFI-payload в имени пользователя."""
    users = _load_users()
    msg = request.args.get("msg", "")

    users_html = ""
    for u in users:
        users_html += f"<tr><td>{u['id']}</td><td style='color:#c8a45a'>{u['username']}</td><td>{u['avatar']}</td></tr>"

    body = f"""
    <div class="card">
      <h2>◈ КАК РАБОТАЕТ SECOND-ORDER LFI</h2>
      <pre>1. Пользователь регистрируется с именем: ../../../../secret/admin.txt
2. Имя сохраняется в users.json (в БД)
3. При просмотре профиля: avatar_path = 'avatars/' + username
4. Функция читает файл по этому пути → LFI</pre>
    </div>

    {'<div class="card"><div class="flag">⚑ ' + msg + '</div></div>' if msg else ''}

    <div class="card">
      <h2>◈ РЕГИСТРАЦИЯ</h2>
      <form method="post" action="/second-order/register">
        <div class="row">
          <input type="text" name="username" placeholder="имя пользователя (попробуй LFI payload)">
          <button type="submit">регистрация</button>
        </div>
      </form>
    </div>
    <div class="card">
      <h2>◈ ПОЛЬЗОВАТЕЛИ В БД</h2>
      <table>
        <tr><th>id</th><th>username</th><th>avatar path</th></tr>
        {users_html if users_html else '<tr><td colspan="3" style="color:#3a3020">нет пользователей</td></tr>'}
      </table>
    </div>
    <div class="card">
      <h2>◈ ПРОСМОТР ПРОФИЛЯ (загружает avatar)</h2>
      <form method="get" action="/second-order/profile">
        <div class="row">
          <input type="text" name="id" placeholder="id пользователя">
          <button type="submit">просмотр</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Second-Order LFI", body,
        level="LEVEL 7 · HARD",
        hint="Зарегистрируйся с именем <code>../../../../secret/admin.txt</code>, "
             "затем открой профиль через <code>/second-order/profile?id=1</code>"
    )


@app.route("/second-order/register", methods=["POST"])
def second_order_register():
    username = request.form.get("username", "").strip()
    if not username:
        return redirect(url_for("second_order"))

    users = _load_users()
    new_id = max((u["id"] for u in users), default=0) + 1
    users.append({
        "id": new_id,
        "username": username,
        "avatar": f"avatars/{username}",   # ← LFI payload хранится в БД
    })
    _save_users(users)
    return redirect(url_for("second_order"))


@app.route("/second-order/profile")
def second_order_profile():
    uid = request.args.get("id", "")
    users = _load_users()
    user = next((u for u in users if str(u["id"]) == uid), None)

    if not user:
        return page("Profile", '<div class="error">Пользователь не найден</div>')

    # ← Вот здесь второй порядок: читаем файл по пути из БД
    avatar_path = user["avatar"]
    content = _read_file_unsafe_raw(avatar_path, base=BASE_DIR)

    flag_found = "HTB{s3c0nd_0rd3r_pwn3d}" in (content or "")
    msg = "?msg=HTB{s3c0nd_0rd3r_pwn3d}" if flag_found else ""

    body = f"""
    <div class="card">
      <h2>◈ ПРОФИЛЬ · {user['username']}</h2>
      <p style="color:#6b5a30;margin-bottom:12px">avatar path (из БД): <span style="color:#8b3a2a">{avatar_path}</span></p>
      <h2>◈ СОДЕРЖИМОЕ ФАЙЛА</h2>
      {content}
    </div>
    {'<div class="card"><div class="flag">⚑ HTB{s3c0nd_0rd3r_pwn3d} · флаг получен!</div></div>' if flag_found else ''}
    <p style="margin-top:12px"><a href="/second-order{msg}" style="color:#6b5a30">← назад</a></p>
    """
    return page(f"Profile · {user['username']}", body, level="LEVEL 7 · HARD")


# ── HELPERS ───────────────────────────────────────────────────────────────────

def _read_file_unsafe(path: str, base: Path) -> str:
    """Читает файл относительно base — намеренно уязвимо."""
    import os as _os
    try:
        full = Path(_os.path.normpath(_os.path.join(str(base), path)))
        content = full.read_text(encoding="utf-8", errors="replace")
        if not content.strip():
            return f'<div class="error">⛔ File is empty: {_escape(path)}</div>'
        return f'<div class="file-content">{_escape(content)}</div>'
    except FileNotFoundError:
        return f'<div class="error">⛔ File not found: {_escape(path)}</div>'
    except PermissionError:
        return f'<div class="error">⛔ Permission denied: {_escape(path)}</div>'
    except Exception as e:
        return f'<div class="error">⛔ Error: {_escape(str(e))}</div>'


def _read_file_unsafe_raw(path: str, base: Path) -> str:
    """Читает файл — путь не нормализуется через base."""
    try:
        p = Path(path) if Path(path).is_absolute() else base / path
        content = p.read_text(encoding="utf-8", errors="replace")
        if not content.strip():
            return f'<div class="error">⛔ File is empty: {_escape(path)}</div>'
        return f'<div class="file-content">{_escape(content)}</div>'
    except FileNotFoundError:
        return f'<div class="error">⛔ File not found: {_escape(path)}</div>'
    except Exception as e:
        return f'<div class="error">⛔ Error: {_escape(str(e))}</div>'


def _escape(s: str) -> str:
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")


def _load_users() -> list:
    if USERS_DB.exists():
        return json.loads(USERS_DB.read_text())
    return []


def _save_users(users: list):
    USERS_DB.parent.mkdir(exist_ok=True)
    USERS_DB.write_text(json.dumps(users, indent=2, ensure_ascii=False))


# ── LEVEL 8 · PHP WRAPPERS (симуляция) ──────────────────────────────────────

@app.route("/wrapper")
def wrapper():
    """Симулирует поведение php://filter — читает файл, кодирует в base64."""
    import base64
    resource = request.args.get("page", "pages/home.txt")

    # Детектируем тип wrapper
    content_html = ""
    path_used = resource

    if resource.startswith("php://filter"):
        # Извлекаем имя файла из resource=...
        import re
        m = re.search(r"resource=(.+)$", resource)
        if m:
            file_path = m.group(1).strip()
            raw = _read_file_content(file_path)
            if raw is None:
                content_html = f'<div class="error">⛔ File not found: {_escape(file_path)}</div>'
            elif "base64-encode" in resource:
                encoded = base64.b64encode(raw.encode()).decode()
                content_html = f'<div class="file-content">{encoded}</div>'
            elif "rot13" in resource:
                import codecs
                content_html = f'<div class="file-content">{_escape(codecs.encode(raw, "rot_13"))}</div>'
            else:
                content_html = f'<div class="file-content">{_escape(raw)}</div>'
        else:
            content_html = '<div class="error">⛔ Invalid filter syntax</div>'
    elif resource.startswith("data://"):
        content_html = '<div class="error">⛔ data:// wrapper disabled (allow_url_include=Off)</div>'
    elif resource.startswith("expect://"):
        content_html = '<div class="error">⛔ expect:// not available</div>'
    else:
        raw = _read_file_content(resource)
        if raw:
            content_html = f'<div class="file-content">{_escape(raw)}</div>'
        else:
            content_html = f'<div class="error">⛔ File not found: {_escape(resource)}</div>'

    body = f"""
    <div class="card">
      <h2>◈ УЯЗВИМЫЙ КОД</h2>
      <pre>resource = request.args.get('page', 'home')
content  = include($resource)   # ← php:// wrappers разрешены!</pre>
    </div>
    <div class="card">
      <h2>◈ РЕЗУЛЬТАТ · {_escape(path_used)}</h2>
      {content_html}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{_escape(resource)}"
                 placeholder="php://filter/convert.base64-encode/resource=/etc/passwd">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "PHP Wrappers", body,
        level="LEVEL 8 · MEDIUM",
        hint="Попробуй: <code>?page=php://filter/convert.base64-encode/resource=pages/flag.txt</code><br>"
             "Ответ придёт в base64 — декодируй для получения флага."
    )

# ── LEVEL 9 · LOG POISONING ──────────────────────────────────────────────────

@app.route("/logpoison")
def logpoison():
    """Уязвимый к log poisoning эндпоинт."""
    lang = request.args.get("page", "home")
    cmd  = request.args.get("cmd", "")

    # Логируем User-Agent (включая PHP-код если передан)
    ua = request.headers.get("User-Agent", "-")
    app.logger.info(f'GET /logpoison "{ua}"')

    # Читаем наш лог
    content = _read_file_unsafe(lang, base=BASE_DIR / "pages")

    # Симулируем выполнение PHP из лога
    log_content = ""
    if "access.log" in lang or "error.log" in lang:
        try:
            log_text = (BASE_DIR / "logs" / "access.log").read_text()
            if "<?php" in log_text and cmd:
                import subprocess
                try:
                    out = subprocess.check_output(cmd, shell=True, timeout=3,
                                                   stderr=subprocess.STDOUT).decode()
                    log_content = f'<div class="flag">⚑ RCE: {_escape(out)}</div>'
                except Exception as e:
                    log_content = f'<div class="error">cmd error: {_escape(str(e))}</div>'
            else:
                log_content = content
        except Exception:
            log_content = content
    else:
        log_content = content

    body = f"""
    <div class="card">
      <h2>◈ КАК РАБОТАЕТ LOG POISONING</h2>
      <pre>1. Отправь запрос с PHP в User-Agent:
   curl -A '&lt;?php system($_GET["cmd"]); ?&gt;' http://127.0.0.1:5000/logpoison

2. Прочитай лог через LFI:
   ?page=../logs/access.log&amp;cmd=id

3. PHP выполнится → RCE!</pre>
    </div>
    <div class="card">
      <h2>◈ РЕЗУЛЬТАТ · {_escape(lang)}</h2>
      {log_content}
    </div>
    <div class="card">
      <h2>◈ ПОПРОБУЙ</h2>
      <form method="get">
        <div class="row">
          <input type="text" name="page" value="{_escape(lang)}"
                 placeholder="../logs/access.log">
          <input type="text" name="cmd" value="{_escape(cmd)}"
                 placeholder="id" style="max-width:120px">
          <button type="submit">читать</button>
        </div>
      </form>
    </div>
    """
    return page(
        "Log Poisoning", body,
        level="LEVEL 9 · HARD",
        hint="Шаг 1: curl -A php-shell http://127.0.0.1:5000/logpoison | Шаг 2: ?page=../logs/access.log&cmd=id"
             "Шаг 2: <code>?page=../logs/access.log&amp;cmd=id</code>"
    )


def _read_file_content(path: str) -> str | None:
    """Читает файл, возвращает строку или None."""
    import os
    try:
        full = Path(os.path.normpath(os.path.join(str(BASE_DIR / "pages"), path)))
        if not full.exists():
            # попробовать как абсолютный
            full = Path(os.path.normpath(os.path.join(str(BASE_DIR), path)))
        content = full.read_text(encoding="utf-8", errors="replace")
        return content if content.strip() else None
    except Exception:
        return None


if __name__ == "__main__":
    print("""
  ✦ VINE LAB · запуск
  ─────────────────────────────
  http://127.0.0.1:5000
  ─────────────────────────────
  ВНИМАНИЕ: только для локального тестирования!
    """)
    app.run(host="127.0.0.1", port=5000, debug=False)
