# VINE LAB · LFI Vulnerability Lab

Тестовый сервер с намеренно уязвимыми страницами для отработки LFI-техник.

## Запуск

```bash
cd vine-lab
pip install flask
python app.py
# → http://127.0.0.1:5000
```

## Уровни

| Маршрут        | Защита                        | Bypass                                      |
|----------------|-------------------------------|---------------------------------------------|
| `/basic`       | нет                           | `?page=../secret/admin.txt`                 |
| `/filtered`    | `str_replace('../', '')`      | `?page=....//secret/admin.txt`              |
| `/encoded`     | проверка на `../` в сырой строке | `?page=%2e%2e%2fsecret%2fadmin.txt`      |
| `/prefix`      | добавляет `lang_` перед вводом | `?lang=/../../secret/admin.txt`            |
| `/extension`   | добавляет `.html` к вводу     | только `.html` файлы                        |
| `/approved`    | regex `^./pages/.+`           | `?page=./pages/../secret/admin.txt`         |
| `/second-order`| LFI через имя пользователя    | регистрация с payload, затем просмотр профиля |

## Флаги

- `pages/flag.txt` → `HTB{v1n3_s33s_4ll_p4ths}` — для уровней 1-6
- `secret/admin.txt` → `HTB{s3c0nd_0rd3r_pwn3d}` — для уровня 7
- `logs/access.log` — для демонстрации log poisoning

## Тест с Vine

```
URL:    http://127.0.0.1:5000/basic?page=home
Params: page
OS:     linux
Depth:  4
```
