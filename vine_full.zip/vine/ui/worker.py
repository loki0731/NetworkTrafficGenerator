"""
Vine · ui/worker.py
QThread-обёртка над ScanEngine.
Все события пробрасываются через Qt-сигналы в главный поток.
"""

from PyQt6.QtCore import QThread, pyqtSignal

from core.scanner import ScanConfig, ScanEngine, Finding, ScanStats


class ScanWorker(QThread):

    # Сигналы → принимает MainWindow
    sig_log      = pyqtSignal(str, str)      # msg, level
    sig_finding  = pyqtSignal(object)        # Finding
    sig_progress = pyqtSignal(object)        # ScanStats
    sig_finished = pyqtSignal(object)        # ScanStats

    def __init__(self, config: ScanConfig, parent=None):
        super().__init__(parent)
        self.config = config
        self._engine: ScanEngine | None = None

    def run(self):
        self._engine = ScanEngine(
            config=self.config,
            on_log=lambda msg, lvl: self.sig_log.emit(msg, lvl),
            on_finding=lambda f: self.sig_finding.emit(f),
            on_progress=lambda s: self.sig_progress.emit(s),
            on_finished=lambda s: self.sig_finished.emit(s),
        )
        self._engine.run()

    def stop(self):
        if self._engine:
            self._engine.stop()
        self.wait(3000)
