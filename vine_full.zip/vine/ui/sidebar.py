"""
Vine · ui/sidebar.py
Боковая панель с формой конфигурации сканирования.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QSpinBox, QComboBox, QCheckBox,
    QPushButton, QFrame, QSizePolicy, QScrollArea,
    QApplication, QInputDialog, QMessageBox, QFileDialog,
)
from PyQt6.QtCore import Qt, pyqtSignal, QThread, pyqtSlot
from PyQt6.QtGui import QFont
import urllib.parse
import re as _re

from core.scanner import ScanConfig
from core.payloads import ENCODING_LABELS


def _hline() -> QFrame:
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    line.setObjectName("h_line")
    line.setFixedHeight(1)
    return line


def _section(text: str) -> QLabel:
    lbl = QLabel(f"◈  {text.upper()}")
    lbl.setObjectName("section_label")
    return lbl


def _field_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("label")
    lbl.setStyleSheet("font-size: 11px; color: #b09060; letter-spacing: 1px;")
    return lbl


class Sidebar(QWidget):

    invoke_requested = pyqtSignal(ScanConfig)   # нажата кнопка
    stop_requested   = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(300)

        self._running = False
        self._db = None   # устанавливается из MainWindow через set_db()
        self._build_ui()

    # ── Построение UI ────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Скролл-область для формы
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        form_widget = QWidget()
        self._form = QVBoxLayout(form_widget)
        self._form.setContentsMargins(14, 14, 14, 14)
        self._form.setSpacing(10)

        self._build_conjuration_section()
        self._form.addWidget(_hline())
        self._build_method_section()
        self._form.addWidget(_hline())
        self._build_sigils_section()
        self._form.addWidget(_hline())
        self._build_arsenal_section()
        self._form.addWidget(_hline())
        self._build_wards_section()
        self._form.addStretch()

        scroll.setWidget(form_widget)
        root.addWidget(scroll)

        # Кнопка — вне скролла, внизу
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(14, 10, 14, 14)
        bl.setSpacing(6)

        ornament = QLabel("⸻  ✦  ⸻")
        ornament.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ornament.setObjectName("label_gold")
        bl.addWidget(ornament)

        # Основная кнопка
        self.btn_invoke = QPushButton("◉  INVOKE VINE")
        self.btn_invoke.setObjectName("btn_invoke")
        self.btn_invoke.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_invoke.clicked.connect(self._on_invoke_clicked)
        self.btn_invoke.setToolTip("Полное сканирование · Ctrl+Enter")
        bl.addWidget(self.btn_invoke)

        # Нижний ряд: Quick Scan + профили
        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        self.btn_quick = QPushButton("⚡ Quick")
        self.btn_quick.setObjectName("btn_toolbar")
        self.btn_quick.setToolTip(
            "Quick Scan — ~100 самых вероятных payloads\n"
            "Глубины 2-5, только plain. Результат за 5-15 секунд.\n"
            "Идеально для быстрой проверки: есть LFI или нет."
        )
        self.btn_quick.clicked.connect(self._on_quick_scan)
        btn_row.addWidget(self.btn_quick)

        self.btn_save_profile = QPushButton("⊞ save")
        self.btn_save_profile.setObjectName("btn_toolbar")
        self.btn_save_profile.setToolTip("Сохранить текущую конфигурацию как профиль")
        self.btn_save_profile.clicked.connect(self._save_profile)
        btn_row.addWidget(self.btn_save_profile)

        self.btn_load_profile = QPushButton("⊟ load")
        self.btn_load_profile.setObjectName("btn_toolbar")
        self.btn_load_profile.setToolTip("Загрузить сохранённый профиль")
        self.btn_load_profile.clicked.connect(self._load_profile)
        btn_row.addWidget(self.btn_load_profile)

        bl.addLayout(btn_row)

        root.addWidget(bottom)

    def _build_conjuration_section(self):
        self._form.addWidget(_section("Conjuration"))

        # URL
        self._form.addWidget(_field_label("Target URL"))
        url_row = QHBoxLayout()
        url_row.setSpacing(6)
        self.inp_url = QLineEdit()
        self.inp_url.setPlaceholderText("http://target.htb/index.php?page=home")
        self.inp_url.setToolTip("Полный URL. Например:\nhttp://target.htb/index.php?page=home")
        self.inp_url.textChanged.connect(self._on_url_changed)
        url_row.addWidget(self.inp_url)

        self.btn_discover = QPushButton("⟳")
        self.btn_discover.setObjectName("btn_toolbar")
        self.btn_discover.setFixedSize(30, 30)
        self.btn_discover.setToolTip(
            "Discover — автоматически найти параметры\n"
            "Парсит URL и страницу, находит все GET/POST параметры"
        )
        self.btn_discover.clicked.connect(self._discover_params)
        url_row.addWidget(self.btn_discover)
        self._form.addLayout(url_row)

        # Params
        self._form.addWidget(_field_label("Parameters  (через пробел)"))
        self.inp_params = QLineEdit()
        self.inp_params.setPlaceholderText("page  lang  language")
        self.inp_params.setToolTip(
            "Параметры URL для тестирования.\n"
            "Нажми ⟳ для автоопределения из URL.\n"
            "Пример: page language file"
        )
        self._form.addWidget(self.inp_params)

        # Статус discover
        self._discover_status = QLabel("")
        self._discover_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")
        self._form.addWidget(self._discover_status)

        # Wordlist
        self._form.addWidget(_field_label("Wordlist  (опционально)"))
        wl_row = QHBoxLayout()
        wl_row.setSpacing(6)
        self.inp_wordlist = QLineEdit()
        self.inp_wordlist.setPlaceholderText("/usr/share/seclists/LFI/...")
        self.inp_wordlist.setToolTip(
            "Путь к файлу с кастомными путями (один путь на строку).\n"
            "Если указан — заменяет стандартный набор целевых файлов.\n"
            "Поддерживает форматы SecLists."
        )
        wl_row.addWidget(self.inp_wordlist)
        btn_wl = QPushButton("…")
        btn_wl.setObjectName("btn_toolbar")
        btn_wl.setFixedSize(30, 30)
        btn_wl.setToolTip("Выбрать файл wordlist")
        btn_wl.clicked.connect(self._browse_wordlist)
        wl_row.addWidget(btn_wl)
        self._form.addLayout(wl_row)

        self._wordlist_status = QLabel("")
        self._wordlist_status.setStyleSheet("font-size: 10px; color: #b09060;")
        self._form.addWidget(self._wordlist_status)
        self.inp_wordlist.textChanged.connect(self._on_wordlist_changed)

        # OS + Depth
        row1 = QHBoxLayout()
        row1.setSpacing(8)

        col_os = QVBoxLayout()
        col_os.addWidget(_field_label("OS Target"))
        self.cmb_os = QComboBox()
        self.cmb_os.addItems(["linux", "windows"])
        self.cmb_os.setToolTip(
            "Linux: /etc/passwd, /proc/*, логи nginx/apache\n"
            "Windows: boot.ini, win.ini, SAM"
        )
        col_os.addWidget(self.cmb_os)
        row1.addLayout(col_os)

        col_depth = QVBoxLayout()
        col_depth.addWidget(_field_label("Depth"))
        self.spn_depth = QSpinBox()
        self.spn_depth.setRange(1, 15)
        self.spn_depth.setValue(8)
        self.spn_depth.setToolTip(
            "Максимальная глубина path traversal.\n"
            "Чем глубже вложен файл приложения — тем больше нужно ../\n"
            "Обычно хватает 6-8. Для HTB чаще всего 4-6."
        )
        col_depth.addWidget(self.spn_depth)
        row1.addLayout(col_depth)
        self._form.addLayout(row1)

        # Threads + Timeout
        row2 = QHBoxLayout()
        row2.setSpacing(8)

        col_thr = QVBoxLayout()
        col_thr.addWidget(_field_label("Threads"))
        self.spn_threads = QSpinBox()
        self.spn_threads.setRange(1, 50)
        self.spn_threads.setValue(10)
        self.spn_threads.setToolTip(
            "Количество параллельных потоков.\n"
            "10-20 — безопасно для большинства серверов.\n"
            "Больше = быстрее, но может вызвать 429/503."
        )
        col_thr.addWidget(self.spn_threads)
        row2.addLayout(col_thr)

        col_to = QVBoxLayout()
        col_to.addWidget(_field_label("Timeout (s)"))
        self.spn_timeout = QSpinBox()
        self.spn_timeout.setRange(1, 60)
        self.spn_timeout.setValue(10)
        self.spn_timeout.setToolTip("Таймаут одного запроса в секундах.")
        col_to.addWidget(self.spn_timeout)
        row2.addLayout(col_to)
        self._form.addLayout(row2)

    def _build_method_section(self):
        """GET / POST переключатель + POST body."""
        self._form.addWidget(_section("Method"))

        method_row = QHBoxLayout()
        method_row.setSpacing(6)

        self.cmb_method = QComboBox()
        self.cmb_method.addItems(["GET", "POST"])
        self.cmb_method.setToolTip(
            "GET — параметр в URL (стандарт)\n"
            "POST — параметр в теле запроса (формы, AJAX)"
        )
        self.cmb_method.currentTextChanged.connect(self._on_method_changed)
        method_row.addWidget(self.cmb_method)
        self._form.addLayout(method_row)

        self._post_body_widget = QWidget()
        post_layout = QVBoxLayout(self._post_body_widget)
        post_layout.setContentsMargins(0, 4, 0, 0)
        post_layout.setSpacing(4)
        post_layout.addWidget(_field_label("POST body  (key=val; key2=val2)"))
        self.inp_post_body = QLineEdit()
        self.inp_post_body.setPlaceholderText("username=admin; action=view")
        self.inp_post_body.setToolTip(
            "Базовые POST-параметры (не тестируемые).\n"
            "Тестируемые параметры добавляются автоматически.\n"
            "Пример: action=view; csrf=abc123"
        )
        post_layout.addWidget(self.inp_post_body)
        self._post_body_widget.setVisible(False)
        self._form.addWidget(self._post_body_widget)

    def _on_method_changed(self, method: str):
        self._post_body_widget.setVisible(method == "POST")

    def _build_arsenal_section(self):
        """PHP Wrappers и Log Poisoning."""
        self._form.addWidget(_section("Arsenal  ·  advanced"))

        self.cb_wrappers = QCheckBox("php:// wrappers")
        self.cb_wrappers.setToolTip(
            "Включить PHP wrapper payloads:\n"
            "  php://filter/convert.base64-encode/resource=FILE\n"
            "  php://filter/read=string.rot13/resource=FILE\n"
            "  php://filter/zlib.deflate/... (WAF bypass)\n"
            "Vine автоматически декодирует ответ и покажет содержимое."
        )
        self._form.addWidget(self.cb_wrappers)

        self.cb_wrappers_rce = QCheckBox("data:// + expect:// RCE")
        self.cb_wrappers_rce.setToolTip(
            "Проверить возможность RCE через wrappers:\n"
            "  data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWy4uLl0pOz8+\n"
            "  expect://id\n"
            "⚠ Требует allow_url_include=On на сервере.\n"
            "Активируется только вместе с php:// wrappers."
        )
        self.cb_wrappers_rce.setEnabled(False)
        self._form.addWidget(self.cb_wrappers_rce)
        self.cb_wrappers.toggled.connect(self.cb_wrappers_rce.setEnabled)

        self.cb_log_poison = QCheckBox("Log Poisoning → RCE")
        self.cb_log_poison.setToolTip(
            "Автоматический детектор Log Poisoning:\n"
            "1. Если traversal нашёл доступный лог (access.log / error.log)\n"
            "2. Vine отправит запрос с <?php system($_GET[\'cmd\']); ?> в User-Agent\n"
            "3. Затем прочитает лог через LFI и добавит ?cmd=id\n"
            "4. Если в ответе uid= — RCE подтверждён!\n"
            "⚠ Работает только после traversal-скана."
        )
        self._form.addWidget(self.cb_log_poison)

    def _build_sigils_section(self):
        self._form.addWidget(_section("Sigils  ·  encodings"))

        self._enc_checks: dict[str, QCheckBox] = {}
        for key, label in ENCODING_LABELS.items():
            cb = QCheckBox(label)
            cb.setChecked(key == "plain")
            cb.setToolTip(self._enc_tooltip(key))
            self._enc_checks[key] = cb
            self._form.addWidget(cb)

    def _build_wards_section(self):
        self._form.addWidget(_section("Wards"))

        self._form.addWidget(_field_label("Cookies"))
        self.inp_cookies = QLineEdit()
        self.inp_cookies.setPlaceholderText("PHPSESSID=abc123; auth=xyz")
        self.inp_cookies.setToolTip(
            "Cookies для авторизованных запросов.\n"
            "Формат: key=value; key2=value2"
        )
        self._form.addWidget(self.inp_cookies)

        self._form.addWidget(_field_label("Extra Headers"))
        self.inp_headers = QLineEdit()
        self.inp_headers.setPlaceholderText("X-Custom: value; Authorization: Bearer …")
        self.inp_headers.setToolTip("Дополнительные HTTP-заголовки. Разделитель: ;")
        self._form.addWidget(self.inp_headers)

        self._form.addWidget(_field_label("Proxy"))
        self.inp_proxy = QLineEdit()
        self.inp_proxy.setPlaceholderText("http://127.0.0.1:8080  (Burp Suite)")
        self.inp_proxy.setToolTip(
            "HTTP-прокси для перехвата запросов.\n"
            "Burp Suite: http://127.0.0.1:8080\n"
            "mitmproxy: http://127.0.0.1:8080"
        )
        self._form.addWidget(self.inp_proxy)

    # ── Действия ─────────────────────────────────────────────────────────────

    def _on_invoke_clicked(self):
        if self._running:
            self.stop_requested.emit()
            return

        config = self._build_config()
        if config:
            self.invoke_requested.emit(config)

    def _on_url_changed(self, raw: str):
        """При изменении URL — автоматически заполнить параметры + валидация."""
        text = raw.strip()
        if not text:
            return

        # Автодобавление схемы
        if text and not text.startswith(("http://", "https://", "ftp://")):
            fixed = "http://" + text
            # Не трогаем поле пока пользователь печатает — только показываем подсказку
            self._discover_status.setText(f"⚠ схема добавлена автоматически: http://")
            self._discover_status.setStyleSheet("font-size: 10px; color: #c8a030;")
            text = fixed

        try:
            parsed = urllib.parse.urlparse(text)
            if not parsed.netloc:
                self._discover_status.setText("⚠ неверный URL — укажи хост")
                self._discover_status.setStyleSheet("font-size: 10px; color: #cc5a4a;")
                return
            qs = urllib.parse.parse_qs(parsed.query)
            if qs:
                params = " ".join(qs.keys())
                self.inp_params.setText(params)
                self._discover_status.setText(f"✓ {len(qs)} param(s) from URL")
                self._discover_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")
        except Exception:
            pass

    def _browse_wordlist(self):
        """Открыть диалог выбора файла wordlist."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Выбрать wordlist",
            "/usr/share/seclists" if __import__("os").path.exists("/usr/share/seclists")
            else __import__("os").path.expanduser("~"),
            "Text files (*.txt);;All files (*)",
        )
        if path:
            self.inp_wordlist.setText(path)

    def _on_wordlist_changed(self, path: str):
        """Показать информацию о выбранном wordlist."""
        path = path.strip()
        if not path:
            self._wordlist_status.setText("")
            return
        try:
            from core.payloads import wordlist_info
            info = wordlist_info(path)
            if "error" in info:
                self._wordlist_status.setText(f"✗ {info['error']}")
                self._wordlist_status.setStyleSheet("font-size: 10px; color: #cc5a4a;")
            else:
                preview = ", ".join(info["preview"][:2])
                self._wordlist_status.setText(
                    f"✓ {info['valid_paths']} paths · {info['size_bytes']//1024}KB · {preview}..."
                )
                self._wordlist_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")
        except Exception as e:
            self._wordlist_status.setText(f"✗ {str(e)[:40]}")
            self._wordlist_status.setStyleSheet("font-size: 10px; color: #cc5a4a;")

    def _discover_params(self):
        """Парсит страницу по URL и ищет все параметры в формах и ссылках."""
        url = self.inp_url.text().strip()
        if not url:
            return

        self.btn_discover.setText("…")
        self.btn_discover.setEnabled(False)
        self._discover_status.setText("fetching page...")
        self._discover_status.setStyleSheet("font-size: 10px; color: #9a7a40;")
        QApplication.processEvents()

        try:
            import requests as _req
            resp = _req.get(url, timeout=8, verify=False,
                           headers={"User-Agent": "Mozilla/5.0"})
            body = resp.text
            found = set()

            # 1. Параметры из query string самого URL
            parsed = urllib.parse.urlparse(url)
            for k in urllib.parse.parse_qs(parsed.query):
                found.add(k)

            # 2. Параметры из HTML форм (input, select, textarea)
            pat1 = _re.compile(r"<(?:input|select|textarea)[^>]+name=[\x27\"](.[^\"\x27]+)[\x27\"]", _re.I)
            for m in pat1.finditer(body):
                found.add(m.group(1))

            # 3. Параметры из href и src ссылок на том же домене
            pat2 = _re.compile(r"(?:href|action|src)=[\x27\"][^\x27\"]*[?]([^\x27\"#]+)[\x27\"]", _re.I)
            for m in pat2.finditer(body):
                for k, _ in urllib.parse.parse_qsl(m.group(1)):
                    found.add(k)

            # Фильтруем шумовые параметры
            noise = {"csrf", "token", "_token", "nonce", "submit", "action",
                     "__requestverificationtoken", "returnurl", "redirect"}
            found = {p for p in found if p.lower() not in noise and len(p) < 30}

            if found:
                self.inp_params.setText(" ".join(sorted(found)))
                self._discover_status.setText(f"✓ found: {', '.join(sorted(found))}")
                self._discover_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")
            else:
                self._discover_status.setText("~ no params found — enter manually")
                self._discover_status.setStyleSheet("font-size: 10px; color: #c8a030;")

        except Exception as e:
            self._discover_status.setText(f"✗ {str(e)[:40]}")
            self._discover_status.setStyleSheet("font-size: 10px; color: #cc5a4a;")
        finally:
            self.btn_discover.setText("⟳")
            self.btn_discover.setEnabled(True)

    def _build_config(self) -> ScanConfig | None:
        url = self.inp_url.text().strip()
        params_raw = self.inp_params.text().strip()

        if not url:
            self.inp_url.setFocus()
            return None

        # Автодобавление схемы
        if url and not url.startswith(("http://", "https://", "ftp://")):
            url = "http://" + url
            self.inp_url.setText(url)

        # Валидация URL
        try:
            parsed_check = urllib.parse.urlparse(url)
            if not parsed_check.netloc:
                self._discover_status.setText("✗ неверный URL")
                self._discover_status.setStyleSheet("font-size: 10px; color: #cc5a4a;")
                self.inp_url.setFocus()
                return None
        except Exception:
            self.inp_url.setFocus()
            return None

        if not params_raw:
            self.inp_params.setFocus()
            return None

        params = params_raw.split()
        encodings = [k for k, cb in self._enc_checks.items() if cb.isChecked()]
        if not encodings:
            encodings = ["plain"]

        cookies = self._parse_kv(self.inp_cookies.text())
        headers = self._parse_kv(self.inp_headers.text())
        proxy = self.inp_proxy.text().strip() or None

        method = self.cmb_method.currentText()
        post_data = self._parse_kv(self.inp_post_body.text()) if method == "POST" else {}

        wordlist = self.inp_wordlist.text().strip()

        return ScanConfig(
            url=url,
            params=params,
            os_type=self.cmb_os.currentText(),
            depth=self.spn_depth.value(),
            threads=self.spn_threads.value(),
            timeout=self.spn_timeout.value(),
            encodings=encodings,
            cookies=cookies,
            extra_headers=headers,
            proxy=proxy,
            method=method,
            post_data=post_data,
            use_wrappers=self.cb_wrappers.isChecked(),
            wrappers_rce=self.cb_wrappers_rce.isChecked(),
            use_log_poison=self.cb_log_poison.isChecked(),
            wordlist_path=wordlist,
        )

    @staticmethod
    def _parse_kv(text: str) -> dict:
        result = {}
        for part in text.split(";"):
            part = part.strip()
            if "=" in part:
                k, _, v = part.partition("=")
                result[k.strip()] = v.strip()
        return result

    # ── Профили + Quick Scan ─────────────────────────────────────────────────

    def set_db(self, db):
        self._db = db

    def _on_quick_scan(self):
        """Запускает Quick Scan — быстрая проверка с ~100 payloads."""
        if self._running:
            return
        config = self._build_config()
        if config:
            config.quick_scan = True
            self.invoke_requested.emit(config)

    def _save_profile(self):
        if not self._db:
            return
        config = self._build_config()
        if not config:
            return
        name, ok = QInputDialog.getText(
            self, "Сохранить профиль",
            "Имя профиля:",
            text=self._url_to_profile_name(config.url),
        )
        if ok and name.strip():
            self._db.save_profile(name.strip(), config)
            self._discover_status.setText(f"✓ profile saved: {name.strip()}")
            self._discover_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")

    def _load_profile(self):
        if not self._db:
            return
        profiles = self._db.list_profiles()
        if not profiles:
            QMessageBox.information(self, "Профили", "Нет сохранённых профилей.")
            return
        names = [f"{p['name']}  [{p['url'][:40]}]" for p in profiles]
        name, ok = QInputDialog.getItem(
            self, "Загрузить профиль", "Выбери профиль:", names, 0, False
        )
        if ok and name:
            idx = names.index(name)
            profile = profiles[idx]
            config = self._db.profile_to_config(profile)
            self._apply_config(config)
            self._discover_status.setText(f"✓ profile loaded: {profile['name']}")
            self._discover_status.setStyleSheet("font-size: 10px; color: #5aaa7a;")

    def _apply_config(self, config):
        """Применяет ScanConfig к полям формы."""
        self.inp_url.setText(config.url)
        self.inp_params.setText(" ".join(config.params))
        idx = self.cmb_os.findText(config.os_type)
        if idx >= 0:
            self.cmb_os.setCurrentIndex(idx)
        self.spn_depth.setValue(config.depth)
        self.spn_threads.setValue(config.threads)
        self.spn_timeout.setValue(config.timeout)

        for key, cb in self._enc_checks.items():
            cb.setChecked(key in config.encodings)

        method = getattr(config, "method", "GET")
        idx_m = self.cmb_method.findText(method)
        if idx_m >= 0:
            self.cmb_method.setCurrentIndex(idx_m)

        post_data = getattr(config, "post_data", {})
        self.inp_post_body.setText(
            "; ".join(f"{k}={v}" for k, v in post_data.items())
        )

        cookies = getattr(config, "cookies", {})
        self.inp_cookies.setText(
            "; ".join(f"{k}={v}" for k, v in cookies.items())
        )

        if getattr(config, "proxy", None):
            self.inp_proxy.setText(config.proxy)

        self.cb_wrappers.setChecked(getattr(config, "use_wrappers", False))
        self.cb_wrappers_rce.setChecked(getattr(config, "wrappers_rce", False))
        self.cb_log_poison.setChecked(getattr(config, "use_log_poison", False))
        self.inp_wordlist.setText(getattr(config, "wordlist_path", ""))

    # ── Состояние ────────────────────────────────────────────────────────────

    def set_running(self, running: bool):
        self._running = running
        if running:
            self.btn_invoke.setText("◉  STOP")
            self.btn_invoke.setProperty("running", "true")
        else:
            self.btn_invoke.setText("◉  INVOKE VINE")
            self.btn_invoke.setProperty("running", "false")
        # Обновление стиля при смене property
        self.btn_invoke.style().unpolish(self.btn_invoke)
        self.btn_invoke.style().polish(self.btn_invoke)

    @staticmethod
    def _url_to_profile_name(url: str) -> str:
        """Генерирует предлагаемое имя профиля из URL."""
        try:
            import urllib.parse as _up
            p = _up.urlparse(url)
            host = p.netloc.replace(":", "_")
            path = p.path.strip("/").split("/")[0] if p.path.strip("/") else ""
            return f"{host}_{path}" if path else host
        except Exception:
            return "profile"

    @staticmethod
    def _enc_tooltip(key: str) -> str:
        tips = {
            "plain": (
                "Стандартный path traversal без кодировки.\n"
                "Пример: ../../../../etc/passwd\n"
                "Включи всегда — базовая техника."
            ),
            "url_encoded": (
                "URL-кодировка символов . и /\n"
                "Пример: %2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd\n"
                "Обходит фильтры, проверяющие сырой ввод."
            ),
            "double_encoded": (
                "Двойная URL-кодировка: % → %25\n"
                "Пример: %252e%252e%252f...\n"
                "Для серверов, декодирующих дважды."
            ),
            "null_byte": (
                "Добавляет %00 в конец payload.\n"
                "Работает на PHP < 5.5 — завершает строку,\n"
                "обрезая добавляемое расширение .php"
            ),
            "null_byte_php": (
                "Добавляет %00.php — обход фильтров,\n"
                "требующих наличия .php в пути.\n"
                "Работает только на очень старых PHP."
            ),
        }
        return tips.get(key, "")
