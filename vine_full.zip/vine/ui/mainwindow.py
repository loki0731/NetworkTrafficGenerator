"""
Vine · ui/mainwindow.py
Главное окно приложения.
"""

from __future__ import annotations

import os
from pathlib import Path

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QSplitter, QTabWidget, QStatusBar, QProgressBar,
    QLabel, QPushButton, QFileDialog, QMessageBox,
    QFrame,
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeySequence, QShortcut, QIcon, QPixmap

from core.scanner import ScanConfig, ScanStats
from core.scanner import Finding as LiveFinding
from storage.db import VineDB
from storage.models import StoredFinding
from ui.sidebar import Sidebar
from ui.panels import LogPanel, ResultsPanel, FindingDetail, HintsPanel, HistoryPanel
from ui.worker import ScanWorker


class MainWindow(QMainWindow):

    def __init__(self, db: VineDB):
        super().__init__()
        self._db = db
        self._worker: ScanWorker | None = None
        self._session_id: int | None = None
        self._stats: ScanStats | None = None

        self.setWindowTitle("VINE  ·  Marquis of Secrets")
        self.setMinimumSize(1200, 760)
        self.resize(1400, 860)

        # Иконка окна — PNG логотип
        for logo_name in ("vine_logo.png", "vine_logo.svg"):
            logo_path = Path(__file__).parent.parent / "assets" / logo_name
            if logo_path.exists():
                self.setWindowIcon(QIcon(str(logo_path)))
                break

        self._build_ui()
        self._load_stylesheet()
        self._connect_shortcuts()
        self._refresh_history()

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_titlebar())
        root.addWidget(self._make_body(), 1)

        self._make_statusbar()

    def _make_titlebar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("titlebar")
        bar.setFixedHeight(52)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(12)

        # Логотип в тайтлбаре
        from PyQt6.QtGui import QPixmap
        logo_path = Path(__file__).parent.parent / "assets" / "vine_logo.png"
        sigil = QLabel()
        sigil.setFixedSize(36, 36)
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(
                36, 36,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            sigil.setPixmap(pix)
        else:
            sigil.setText("✦")
            sigil.setObjectName("label_gold")
        layout.addWidget(sigil)

        title = QLabel("VINE")
        title.setObjectName("app_title")
        layout.addWidget(title)

        sep = QLabel("·")
        sep.setObjectName("app_subtitle")
        layout.addWidget(sep)

        sub = QLabel("local file inclusion scanner")
        sub.setObjectName("app_subtitle")
        layout.addWidget(sub)

        layout.addStretch()

        version = QLabel("marquis of secrets  ·  v1.0")
        version.setObjectName("app_subtitle")
        layout.addWidget(version)

        return bar

    def _make_body(self) -> QSplitter:
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(1)

        # Левая панель — форма
        self._sidebar = Sidebar()
        self._sidebar.set_db(self._db)
        self._sidebar.invoke_requested.connect(self._on_invoke)
        self._sidebar.stop_requested.connect(self._on_stop)
        splitter.addWidget(self._sidebar)

        # Центр — вкладки
        center = QWidget()
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        self._tabs = QTabWidget()
        self._tabs.setTabPosition(QTabWidget.TabPosition.North)

        self._log_panel     = LogPanel()
        self._results_panel = ResultsPanel()
        self._hints_panel   = HintsPanel()
        self._history_panel = HistoryPanel()

        self._tabs.addTab(self._log_panel,     "◈  Ritual Log")
        self._tabs.addTab(self._results_panel, "◈  Revelations  (0)")
        self._tabs.addTab(self._hints_panel,   "◈  Codex")
        self._tabs.addTab(self._history_panel, "◈  History")

        self._results_panel.finding_selected.connect(self._on_finding_selected)
        self._history_panel.session_selected.connect(self._on_history_session)

        center_layout.addWidget(self._tabs)
        splitter.addWidget(center)

        # Правая панель — детали находки
        self._detail_panel = FindingDetail()
        self._detail_panel.notes_saved.connect(self._on_notes_saved)
        splitter.addWidget(self._detail_panel)

        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)

        return splitter

    def _make_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        sb.setObjectName("statusbar")

        self._sb_dot   = QLabel("●")
        self._sb_dot.setObjectName("label")
        self._sb_dot.setStyleSheet("font-size: 13px; color: #9a7a40;")
        sb.addWidget(self._sb_dot)

        self._sb_status = QLabel("ready")
        self._sb_status.setObjectName("label")
        self._sb_status.setStyleSheet("font-size: 12px; color: #b09060; font-weight: bold;")
        sb.addWidget(self._sb_status)

        self._sb_progress = QProgressBar()
        self._sb_progress.setFixedWidth(200)
        self._sb_progress.setFixedHeight(3)
        self._sb_progress.setTextVisible(False)
        self._sb_progress.setValue(0)
        sb.addWidget(self._sb_progress)

        sb.addWidget(QLabel(""), 1)  # spacer

        self._sb_found = QLabel("")
        self._sb_found.setObjectName("label_gold")
        self._sb_found.setStyleSheet("font-size: 13px; color: #e8c060; font-weight: bold;")
        sb.addPermanentWidget(self._sb_found)

        self._sb_time = QLabel("")
        self._sb_time.setObjectName("label")
        self._sb_time.setStyleSheet("font-size: 12px; color: #9a7a40;")
        sb.addPermanentWidget(self._sb_time)

        # Кнопки экспорта
        btn_txt = QPushButton("⬇ .txt")
        btn_txt.setObjectName("btn_toolbar")
        btn_txt.setFixedHeight(24)
        btn_txt.clicked.connect(lambda: self._export("txt"))
        sb.addPermanentWidget(btn_txt)

        btn_json = QPushButton("⬇ .json")
        btn_json.setObjectName("btn_toolbar")
        btn_json.setFixedHeight(24)
        btn_json.clicked.connect(lambda: self._export("json"))
        sb.addPermanentWidget(btn_json)

        btn_md = QPushButton("⬇ .md")
        btn_md.setObjectName("btn_toolbar")
        btn_md.setFixedHeight(24)
        btn_md.setToolTip("Экспорт в Markdown — write-up для HTB")
        btn_md.clicked.connect(lambda: self._export("md"))
        sb.addPermanentWidget(btn_md)

        # Таймер для отображения времени
        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick_timer)

    # ── Shortcuts ────────────────────────────────────────────────────────────

    def _connect_shortcuts(self):
        QShortcut(QKeySequence("Ctrl+Return"), self).activated.connect(
            self._sidebar.btn_invoke.click
        )
        QShortcut(QKeySequence("Ctrl+L"), self).activated.connect(
            lambda: self._tabs.setCurrentIndex(0)
        )
        QShortcut(QKeySequence("Ctrl+R"), self).activated.connect(
            lambda: self._tabs.setCurrentIndex(1)
        )

    # ── Scan lifecycle ───────────────────────────────────────────────────────

    def _on_invoke(self, config: ScanConfig):
        # Сбросить предыдущее
        self._log_panel.clear_log()
        self._results_panel.clear()
        self._detail_panel.show_finding(None)
        self._detail_panel.set_scan_config(config)
        self._tabs.setCurrentIndex(0)
        self._update_results_tab(0)
        self._sb_found.setText("")

        # Создать сессию в БД
        self._session_id = self._db.create_session(config)

        # Запустить worker
        self._worker = ScanWorker(config)
        self._worker.sig_log.connect(self._on_log)
        self._worker.sig_finding.connect(self._on_finding)
        self._worker.sig_progress.connect(self._on_progress)
        self._worker.sig_finished.connect(self._on_finished)
        self._worker.start()

        self._sidebar.set_running(True)
        self._set_status("running", "scanning...")
        self._timer.start()

    def _on_stop(self):
        if self._worker:
            self._worker.stop()

    # ── Сигналы от сканера ───────────────────────────────────────────────────

    def _on_log(self, msg: str, level: str):
        self._log_panel.append(msg, level)

    def _on_finding(self, finding: LiveFinding):
        if self._session_id is None:
            return
        fid = self._db.save_finding(self._session_id, finding)

        from storage.models import StoredFinding
        sf = StoredFinding(
            id=fid,
            session_id=self._session_id,
            discovered_at=finding.timestamp,
            param=finding.param,
            target_file=finding.payload.target_file,
            raw_payload=finding.payload.raw,
            encoded_payload=finding.payload.encoded,
            encoding=finding.payload.encoding,
            technique=finding.payload.technique,
            matched_pattern=finding.matched_pattern,
            status_code=finding.status_code,
            response_length=finding.response_length,
            baseline_length=finding.baseline_length,
            size_delta=finding.size_delta,
            elapsed_ms=finding.elapsed_ms,
            url=finding.url,
            notes="",
            method=getattr(finding, "method", "GET"),
            is_wrapper=getattr(finding, "is_wrapper", False),
            decoded_content=getattr(finding, "decoded_content", ""),
        )
        self._results_panel.add_finding(sf)
        count = self._results_panel.count
        self._update_results_tab(count)
        self._sb_found.setText(f"✦ {count} revealed")

    def _on_progress(self, stats: ScanStats):
        self._stats = stats
        pct = int(stats.progress * 100)
        self._sb_progress.setValue(pct)
        self._db.update_session_progress(
            self._session_id, stats.total, stats.done, stats.found, stats.errors
        )

    def _on_finished(self, stats: ScanStats):
        self._stats = stats
        self._timer.stop()
        self._sidebar.set_running(False)

        status = "stopped" if stats.done < stats.total else "done"
        self._db.finish_session(self._session_id, status, stats)

        self._set_status(
            "done",
            f"complete · {stats.done}/{stats.total} · {stats.found} revealed · {stats.elapsed:.1f}s"
        )
        self._sb_progress.setValue(100)
        self._refresh_history()

        if stats.found > 0:
            self._tabs.setCurrentIndex(1)

    # ── История ─────────────────────────────────────────────────────────────

    def _refresh_history(self):
        sessions = self._db.list_sessions()
        self._history_panel.load_sessions(sessions)

    def _on_history_session(self, session_id: int):
        findings = self._db.get_findings(session_id)

        # Дедупликация: для каждого (param, target_file) — только лучшая находка
        # strong (конкретный паттерн) вытесняет эвристику size_delta
        seen: dict[tuple, str] = {}
        deduped = []
        for f in findings:
            key = (f.param, f.target_file)
            is_strong = not f.matched_pattern.startswith("size_delta")
            prev = seen.get(key)
            if prev == "strong":
                continue
            if prev is None or (prev == "heuristic" and is_strong):
                seen[key] = "strong" if is_strong else "heuristic"
                if prev == "heuristic":
                    deduped = [x for x in deduped
                               if not (x.param == f.param and x.target_file == f.target_file)]
                deduped.append(f)

        self._results_panel.load_findings(deduped)
        self._update_results_tab(len(deduped))
        self._tabs.setCurrentIndex(1)

        session = self._db.get_session(session_id)
        if session:
            raw_count = len(findings)
            dedup_count = len(deduped)
            dedup_note = f" (dedup: {raw_count}→{dedup_count})" if raw_count != dedup_count else ""
            self._set_status(
                "done",
                f"session #{session_id} · {dedup_count} findings{dedup_note} · {session.status}"
            )

    # ── Детали находки ───────────────────────────────────────────────────────

    def _on_finding_selected(self, finding):
        self._detail_panel.show_finding(finding)

    def _on_notes_saved(self, finding_id: int, notes: str):
        self._db.update_finding_notes(finding_id, notes)

    # ── Экспорт ──────────────────────────────────────────────────────────────

    def _export(self, fmt: str):
        if self._session_id is None:
            QMessageBox.information(self, "Vine", "Нет активной сессии для экспорта.")
            return

        ext = f"*.{fmt}"
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить результаты", f"vine_session_{self._session_id}.{fmt}", ext
        )
        if not path:
            return

        if fmt == "txt":
            content = self._db.export_session_txt(self._session_id)
        elif fmt == "md":
            content = self._db.export_session_md(self._session_id)
        else:
            content = self._db.export_session_json(self._session_id)

        Path(path).write_text(content, encoding="utf-8")
        self._log_panel.append(f"exported → {path}", "ok")

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _update_results_tab(self, count: int):
        label = f"◈  Revelations  ({count})" if count else "◈  Revelations  (0)"
        self._tabs.setTabText(1, label)

    def _set_status(self, state: str, text: str):
        colors = {"running": "#4a8a6a", "done": "#6b5a30", "ready": "#3a3020"}
        color = colors.get(state, "#3a3020")
        self._sb_dot.setStyleSheet(f"color: {color}")
        self._sb_status.setText(text)

    def _tick_timer(self):
        if self._stats:
            self._sb_time.setText(f"{self._stats.elapsed:.1f}s")

    def _load_stylesheet(self):
        qss_path = Path(__file__).parent.parent / "theme" / "grimoire.qss"
        if qss_path.exists():
            self.setStyleSheet(qss_path.read_text(encoding="utf-8"))

    def cleanup(self):
        """Вызывается из main() перед sys.exit() — корректно останавливаем потоки."""
        if self._worker and self._worker.isRunning():
            self._worker.stop()
            self._worker.wait(3000)   # ждём максимум 3 сек
        if hasattr(self, '_timer'):
            self._timer.stop()

    def closeEvent(self, event):
        if self._worker and self._worker.isRunning():
            self._worker.stop()
            self._worker.wait(2000)
        event.accept()
