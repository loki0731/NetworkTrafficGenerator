#!/usr/bin/env python3
"""
Vine · main.py
Точка входа. Запуск: python main.py
"""

import sys
from pathlib import Path

# Добавляем корень проекта в sys.path
sys.path.insert(0, str(Path(__file__).parent))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from storage.db import VineDB
from ui.mainwindow import MainWindow


def main():
    # Включаем HiDPI
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("Vine")
    app.setApplicationVersion("1.0")

    # Базовый шрифт — чуть крупнее для читаемости
    font = QFont("Courier New", 13)
    font.setWeight(QFont.Weight.Normal)
    app.setFont(font)

    # БД в домашней директории пользователя
    db = VineDB()

    window = MainWindow(db)
    window.show()

    ret = app.exec()
    # Ждём завершения всех потоков перед выходом — иначе IOT instruction
    window.cleanup()
    sys.exit(ret)


if __name__ == "__main__":
    main()
