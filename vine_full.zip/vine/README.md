# VINE · Marquis of Secrets
### LFI Scanner · Desktop App for Penetration Testing

```
 ██╗   ██╗██╗███╗   ██╗███████╗
 ██║   ██║██║████╗  ██║██╔════╝
 ██║   ██║██║██╔██╗ ██║█████╗
 ╚██╗ ██╔╝██║██║╚██╗██║██╔══╝
  ╚████╔╝ ██║██║ ╚████║███████╗
   ╚═══╝  ╚═╝╚═╝  ╚═══╝╚══════╝
```

Десктопный сканер Local File Inclusion уязвимостей с графическим интерфейсом.  
Назван в честь 45-го духа Гоэтии — Vine, маркиза, открывающего потайные места.

> ⚠️ Используй только на системах, для которых у тебя есть явное разрешение.

---

## Установка

```bash
git clone <repo>
cd vine
pip install -r requirements.txt
python main.py
```

**Требования:** Python 3.10+, PyQt6, Linux/macOS/Windows с GUI

---

## Возможности

### Сканирование
| Режим | Описание |
|-------|----------|
| **Full Scan** | Тысячи payloads, настраиваемая глубина (1-15), все кодировки |
| **Quick Scan ⚡** | ~138 payloads, результат за 5-15 секунд |
| **Wordlist** | Загрузить свой список путей (SecLists и другие) |
| **GET / POST** | Оба метода, включая базовые POST-параметры |

### Техники обхода
- **Path Traversal** — `../`, `....//`, `..././` разной глубины
- **Prefix Bypass** — `/../../../../` для обхода `lang_` и аналогичных префиксов
- **Approved Path Bypass** — `./languages/../../../../` для обхода regex-фильтров
- **URL Encoding** — `%2e%2e%2f`, двойное кодирование `%252e%252e%252f`
- **Null Byte** — `%00`, `%00.php` для старых PHP < 5.5
- **PHP Wrappers** — `php://filter` base64/rot13/zlib, `php://input`, `data://`, `expect://`

### Обнаружение
- Паттерн-матч по содержимому (`root:x:0:0`, `HTB{`, `127.0.0.1` и др.)
- Эвристика по росту размера ответа
- Автоматическая фильтрация ложных срабатываний (`file not found`, пустые файлы)
- Дедупликация — один результат на файл, лучший payload

### RCE-консоль
После нахождения `php://input` или `data://` — встроенный терминал прямо в интерфейсе:
- Выполнение произвольных команд
- 15 кнопок быстрых команд (`id`, `whoami`, `uname -a`, SUID, флаги и др.)
- Log Poisoning детектор — автоматически при нахождении доступного лога

### UI
- Живой лог сканирования с цветовой разметкой
- Таблица Revelations с индикаторами подтверждения (зелёный/жёлтый/синий)
- Кнопка `⎘` — копировать payload одним кликом
- `⎘ curl-команда` — готовая команда для терминала
- Кнопка `▶ читать файл` — загружает содержимое прямо в интерфейсе
- История всех сессий с дедупликацией при загрузке
- Профили — сохранить/загрузить конфигурацию
- Экспорт: `.txt`, `.json`, `.md` (Markdown write-up для HTB)

---

## Структура проекта

```
vine/
├── main.py                  # точка входа
├── requirements.txt
├── README.md
│
├── core/
│   ├── payloads.py          # traversal payloads, quick scan, wordlist import
│   ├── scanner.py           # движок сканирования (QThread-совместимый)
│   ├── wrappers.py          # PHP wrapper payloads и Log Poisoning
│   └── rce.py               # RCE-консоль (php://input, data://, log poison)
│
├── storage/
│   ├── db.py                # SQLite хранилище (~/.vine/vine.db)
│   └── models.py            # ScanSession, StoredFinding
│
├── ui/
│   ├── mainwindow.py        # главное окно, вкладки, экспорт
│   ├── sidebar.py           # форма конфигурации, профили, Quick Scan
│   ├── panels.py            # лог, результаты, RCE-консоль, кодекс, история
│   └── worker.py            # QThread обёртка над ScanEngine
│
└── theme/
    └── grimoire.qss         # тема Grimoire (чёрный + золото)
```

---

## Быстрый старт с vine-lab

Тестовый сервер с намеренно уязвимыми страницами:

```bash
cd vine-lab
pip install flask
python app.py
# → http://127.0.0.1:5000
```

| URL | Уровень | Защита |
|-----|---------|--------|
| `/basic?page=home` | Easy | нет |
| `/filtered?page=home` | Easy | `str_replace('../')` нерекурсивно |
| `/encoded?page=home` | Medium | фильтр `../` в сырой строке |
| `/prefix?lang=en` | Medium | префикс `lang_` |
| `/extension?page=home` | Medium | суффикс `.html` |
| `/approved?page=./pages/home.txt` | Hard | regex `^./pages/` |
| `/second-order` | Hard | LFI через имя пользователя в БД |
| `/wrapper?page=home.txt` | Medium | симуляция `php://filter` |
| `/logpoison?page=home` | Hard | Log Poisoning → RCE |

**Флаги:**
- `pages/flag.txt` → `HTB{v1n3_s33s_4ll_p4ths}`
- `secret/admin.txt` → `HTB{s3c0nd_0rd3r_pwn3d}`

---

## Хранилище

Все результаты в `~/.vine/vine.db` (SQLite). Автоматическая миграция схемы при обновлении.

---

## Горячие клавиши

| Клавиша | Действие |
|---------|----------|
| `Ctrl+Enter` | Запустить сканирование |
| `Ctrl+L` | Вкладка Ritual Log |
| `Ctrl+R` | Вкладка Revelations |
