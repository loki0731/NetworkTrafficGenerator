"""
Vine · storage/db.py
SQLite-хранилище сессий и находок.

Схема:
  scan_sessions  — один запуск сканера
  findings       — каждая найденная уязвимость в рамках сессии
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from storage.models import ScanSession, StoredFinding


DEFAULT_DB_PATH = Path.home() / ".vine" / "vine.db"


class VineDB:

    def __init__(self, path: Path | str = DEFAULT_DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    # ── Подключение ──────────────────────────────────────────────────────────

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ── Схема ────────────────────────────────────────────────────────────────

    def _init_schema(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS scan_sessions (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at  REAL    NOT NULL,
                    finished_at REAL,
                    url         TEXT    NOT NULL,
                    params      TEXT    NOT NULL,   -- JSON list
                    os_type     TEXT    NOT NULL,
                    depth       INTEGER NOT NULL,
                    threads     INTEGER NOT NULL,
                    encodings   TEXT    NOT NULL,   -- JSON list
                    proxy       TEXT,
                    cookies     TEXT,               -- JSON dict
                    total       INTEGER DEFAULT 0,
                    done        INTEGER DEFAULT 0,
                    found_count INTEGER DEFAULT 0,
                    errors      INTEGER DEFAULT 0,
                    status      TEXT    DEFAULT 'running'  -- running/done/stopped/error
                );

                CREATE TABLE IF NOT EXISTS findings (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id      INTEGER NOT NULL REFERENCES scan_sessions(id) ON DELETE CASCADE,
                    discovered_at   REAL    NOT NULL,
                    param           TEXT    NOT NULL,
                    target_file     TEXT    NOT NULL,
                    raw_payload     TEXT    NOT NULL,
                    encoded_payload TEXT    NOT NULL,
                    encoding        TEXT    NOT NULL,
                    technique       TEXT    NOT NULL,
                    matched_pattern TEXT    NOT NULL,
                    status_code     INTEGER NOT NULL,
                    response_length INTEGER NOT NULL,
                    baseline_length INTEGER NOT NULL,
                    size_delta      INTEGER NOT NULL,
                    elapsed_ms      INTEGER NOT NULL,
                    url             TEXT    NOT NULL,
                    notes           TEXT    DEFAULT '',
                    method          TEXT    DEFAULT 'GET',
                    is_wrapper      INTEGER DEFAULT 0,
                    decoded_content TEXT    DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_findings_session
                    ON findings(session_id);
                CREATE INDEX IF NOT EXISTS idx_sessions_created
                    ON scan_sessions(created_at DESC);

                CREATE TABLE IF NOT EXISTS profiles (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    name        TEXT    NOT NULL UNIQUE,
                    created_at  REAL    NOT NULL,
                    updated_at  REAL    NOT NULL,
                    url         TEXT    NOT NULL,
                    params      TEXT    NOT NULL,   -- JSON list
                    os_type     TEXT    NOT NULL DEFAULT 'linux',
                    depth       INTEGER NOT NULL DEFAULT 6,
                    threads     INTEGER NOT NULL DEFAULT 10,
                    timeout     INTEGER NOT NULL DEFAULT 10,
                    encodings   TEXT    NOT NULL DEFAULT '["plain"]',
                    method      TEXT    NOT NULL DEFAULT 'GET',
                    post_data   TEXT    NOT NULL DEFAULT '{}',
                    cookies     TEXT    NOT NULL DEFAULT '{}',
                    headers     TEXT    NOT NULL DEFAULT '{}',
                    proxy       TEXT,
                    use_wrappers    INTEGER DEFAULT 0,
                    wrappers_rce    INTEGER DEFAULT 0,
                    use_log_poison  INTEGER DEFAULT 0,
                    notes       TEXT    DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_profiles_name
                    ON profiles(name);
            """)
            # Миграция: добавляем новые колонки если их нет (для старых БД)
            existing = {row[1] for row in conn.execute("PRAGMA table_info(findings)")}
            for col, defn in [
                ("method",          "TEXT DEFAULT 'GET'"),
                ("is_wrapper",      "INTEGER DEFAULT 0"),
                ("decoded_content", "TEXT DEFAULT ''"),
            ]:
                if col not in existing:
                    conn.execute(f"ALTER TABLE findings ADD COLUMN {col} {defn}")

    # ── Sessions ─────────────────────────────────────────────────────────────

    def create_session(self, config) -> int:
        """Создаёт запись сессии и возвращает её id."""
        with self._conn() as conn:
            cur = conn.execute(
                """
                INSERT INTO scan_sessions
                    (created_at, url, params, os_type, depth, threads,
                     encodings, proxy, cookies, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'running')
                """,
                (
                    time.time(),
                    config.url,
                    json.dumps(config.params),
                    config.os_type,
                    config.depth,
                    config.threads,
                    json.dumps(config.encodings),
                    config.proxy,
                    json.dumps(config.cookies),
                ),
            )
            return cur.lastrowid

    def update_session_progress(self, session_id: int, total: int, done: int, found: int, errors: int):
        with self._conn() as conn:
            conn.execute(
                "UPDATE scan_sessions SET total=?, done=?, found_count=?, errors=? WHERE id=?",
                (total, done, found, errors, session_id),
            )

    def finish_session(self, session_id: int, status: str, stats):
        with self._conn() as conn:
            conn.execute(
                """
                UPDATE scan_sessions
                SET finished_at=?, status=?, total=?, done=?, found_count=?, errors=?
                WHERE id=?
                """,
                (
                    time.time(), status,
                    stats.total, stats.done, stats.found, stats.errors,
                    session_id,
                ),
            )

    def get_session(self, session_id: int) -> ScanSession | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM scan_sessions WHERE id=?", (session_id,)
            ).fetchone()
        return ScanSession.from_row(row) if row else None

    def list_sessions(self, limit: int = 50) -> list[ScanSession]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM scan_sessions ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [ScanSession.from_row(r) for r in rows]

    def delete_session(self, session_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM scan_sessions WHERE id=?", (session_id,))

    # ── Findings ─────────────────────────────────────────────────────────────

    def save_finding(self, session_id: int, finding) -> int:
        """Сохраняет Finding из core/scanner.py."""
        with self._conn() as conn:
            cur = conn.execute(
                """
                INSERT INTO findings
                    (session_id, discovered_at, param, target_file,
                     raw_payload, encoded_payload, encoding, technique,
                     matched_pattern, status_code, response_length,
                     baseline_length, size_delta, elapsed_ms, url,
                     method, is_wrapper, decoded_content)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    finding.timestamp,
                    finding.param,
                    finding.payload.target_file,
                    finding.payload.raw,
                    finding.payload.encoded,
                    finding.payload.encoding,
                    finding.payload.technique,
                    finding.matched_pattern,
                    finding.status_code,
                    finding.response_length,
                    finding.baseline_length,
                    finding.size_delta,
                    finding.elapsed_ms,
                    finding.url,
                    getattr(finding, "method", "GET"),
                    int(getattr(finding, "is_wrapper", False)),
                    getattr(finding, "decoded_content", ""),
                ),
            )
            return cur.lastrowid

    def get_findings(self, session_id: int) -> list[StoredFinding]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM findings WHERE session_id=? ORDER BY discovered_at",
                (session_id,),
            ).fetchall()
        return [StoredFinding.from_row(r) for r in rows]

    def update_finding_notes(self, finding_id: int, notes: str):
        with self._conn() as conn:
            conn.execute(
                "UPDATE findings SET notes=? WHERE id=?", (notes, finding_id)
            )

    def delete_finding(self, finding_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM findings WHERE id=?", (finding_id,))

    # ── Экспорт ──────────────────────────────────────────────────────────────

    def export_session_txt(self, session_id: int) -> str:
        session = self.get_session(session_id)
        findings = self.get_findings(session_id)

        lines = [
            "═" * 60,
            "  VINE · LFI Scanner · Export",
            "═" * 60,
            f"  session   #{session_id}",
            f"  target    {session.url}",
            f"  params    {', '.join(session.params)}",
            f"  os        {session.os_type}",
            f"  status    {session.status}",
            f"  found     {session.found_count}",
            f"  created   {session.created_at_fmt}",
            "─" * 60,
            "",
        ]
        for f in findings:
            lines += [
                f"  ✦ {f.target_file}",
                f"    param     {f.param}",
                f"    encoding  {f.encoding}",
                f"    technique {f.technique}",
                f"    pattern   {f.matched_pattern}",
                f"    payload   {f.raw_payload}",
                f"    url       {f.url}",
                f"    delta     +{f.size_delta} bytes",
                f"    elapsed   {f.elapsed_ms}ms",
                f"    notes     {f.notes}" if f.notes else "",
                "",
            ]
        lines.append("═" * 60)
        return "\n".join(l for l in lines if l is not None)

    def export_session_json(self, session_id: int) -> str:
        session = self.get_session(session_id)
        findings = self.get_findings(session_id)
        return json.dumps({
            "session": session.to_dict(),
            "findings": [f.to_dict() for f in findings],
        }, indent=2, ensure_ascii=False)

    def export_session_md(self, session_id: int) -> str:
        """Экспорт в Markdown — удобный write-up для HTB."""
        session = self.get_session(session_id)
        findings = self.get_findings(session_id)
        nl = "\n"

        parts = []
        parts.append(f"# VINE · LFI Scan Report{nl}")
        parts.append(f"{nl}**Target:** `{session.url}`  ")
        parts.append(f"{nl}**Date:** {session.created_at_fmt}  ")
        parts.append(f"{nl}**Findings:** {session.found_count}  ")
        parts.append(f"{nl}**Params:** {', '.join(session.params)}  ")
        parts.append(f"{nl}**OS:** {session.os_type}  ")
        parts.append(f"{nl}{nl}---{nl}")

        if not findings:
            parts.append(f"{nl}*No vulnerabilities found.*{nl}")
            return "".join(parts)

        # Сводка
        parts.append(f"{nl}## Summary{nl}{nl}")
        parts.append("| File | Param | Encoding | Pattern | Δ bytes |" + nl)
        parts.append("|------|-------|----------|---------|---------|" + nl)
        for f in findings:
            pat = f.matched_pattern.replace("|", "/")
            parts.append(f"| `{f.target_file}` | `{f.param}` | {f.encoding} | `{pat}` | +{f.size_delta} |{nl}")
        parts.append(f"{nl}---{nl}")

        # Детали
        parts.append(f"{nl}## Findings{nl}")
        for i, f in enumerate(findings, 1):
            confirmed = not f.matched_pattern.startswith("size_delta")
            badge = "Confirmed" if confirmed else "Heuristic"
            parts.append(f"{nl}### {i}. `{f.target_file}`{nl}{nl}")
            parts.append(f"**Status:** {badge}  {nl}")
            parts.append(f"**Param:** `{f.param}`  {nl}")
            parts.append(f"**Encoding:** `{f.encoding}`  {nl}")
            parts.append(f"**Technique:** {f.technique}  {nl}")
            parts.append(f"**Pattern:** `{f.matched_pattern}`  {nl}")
            parts.append(f"**Delta:** +{f.size_delta} bytes / {f.elapsed_ms}ms  {nl}")
            parts.append(f"{nl}**Payload:**{nl}```{nl}{f.raw_payload}{nl}```{nl}")
            parts.append(f"{nl}**URL:**{nl}```{nl}{f.url}{nl}```{nl}")
            parts.append(f'{nl}**curl:**{nl}```bash{nl}curl -s "{f.url}"{nl}```{nl}')
            if f.notes:
                parts.append(f"{nl}**Notes:** {f.notes}{nl}")
            parts.append(f"{nl}---{nl}")

        parts.append(f"{nl}## Next Steps{nl}{nl}")
        steps = [
            "Verify findings manually in browser",
            "Check for Log Poisoning → RCE (if logs accessible)",
            "Try `php://filter` wrappers for source code disclosure",
            "Check `/proc/self/environ` for env variables",
            "Look for SSH keys in `/root/.ssh/id_rsa`",
        ]
        for s in steps:
            parts.append(f"- [ ] {s}{nl}")
        parts.append(f"{nl}---{nl}{nl}*Generated by VINE · Marquis of Secrets*{nl}")

        return "".join(parts)

    # ── Profiles ─────────────────────────────────────────────────────────────

    def save_profile(self, name: str, config) -> int:
        """Сохраняет профиль из ScanConfig. Создаёт или обновляет по имени."""
        now = time.time()
        with self._conn() as conn:
            cur = conn.execute(
                """
                INSERT INTO profiles
                    (name, created_at, updated_at, url, params, os_type, depth,
                     threads, timeout, encodings, method, post_data, cookies,
                     headers, proxy, use_wrappers, wrappers_rce, use_log_poison)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(name) DO UPDATE SET
                    updated_at=excluded.updated_at,
                    url=excluded.url, params=excluded.params,
                    os_type=excluded.os_type, depth=excluded.depth,
                    threads=excluded.threads, timeout=excluded.timeout,
                    encodings=excluded.encodings, method=excluded.method,
                    post_data=excluded.post_data, cookies=excluded.cookies,
                    headers=excluded.headers, proxy=excluded.proxy,
                    use_wrappers=excluded.use_wrappers,
                    wrappers_rce=excluded.wrappers_rce,
                    use_log_poison=excluded.use_log_poison
                """,
                (
                    name, now, now,
                    config.url,
                    json.dumps(config.params),
                    config.os_type,
                    config.depth,
                    config.threads,
                    config.timeout,
                    json.dumps(config.encodings),
                    getattr(config, "method", "GET"),
                    json.dumps(getattr(config, "post_data", {})),
                    json.dumps(getattr(config, "cookies", {})),
                    json.dumps(getattr(config, "extra_headers", {})),
                    getattr(config, "proxy", None),
                    int(getattr(config, "use_wrappers", False)),
                    int(getattr(config, "wrappers_rce", False)),
                    int(getattr(config, "use_log_poison", False)),
                ),
            )
            return cur.lastrowid

    def list_profiles(self) -> list[dict]:
        """Возвращает все профили, отсортированные по дате обновления."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM profiles ORDER BY updated_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def get_profile(self, profile_id: int) -> dict | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM profiles WHERE id=?", (profile_id,)
            ).fetchone()
        return dict(row) if row else None

    def get_profile_by_name(self, name: str) -> dict | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM profiles WHERE name=?", (name,)
            ).fetchone()
        return dict(row) if row else None

    def delete_profile(self, profile_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM profiles WHERE id=?", (profile_id,))

    def profile_to_config(self, profile: dict):
        """Конвертирует dict профиля обратно в ScanConfig."""
        from core.scanner import ScanConfig
        return ScanConfig(
            url=profile["url"],
            params=json.loads(profile["params"]),
            os_type=profile["os_type"],
            depth=profile["depth"],
            threads=profile["threads"],
            timeout=profile["timeout"],
            encodings=json.loads(profile["encodings"]),
            method=profile.get("method", "GET"),
            post_data=json.loads(profile.get("post_data", "{}")),
            cookies=json.loads(profile.get("cookies", "{}")),
            extra_headers=json.loads(profile.get("headers", "{}")),
            proxy=profile.get("proxy"),
            use_wrappers=bool(profile.get("use_wrappers", 0)),
            wrappers_rce=bool(profile.get("wrappers_rce", 0)),
            use_log_poison=bool(profile.get("use_log_poison", 0)),
        )
