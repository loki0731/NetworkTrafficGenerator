"""
Vine · storage/models.py
Модели данных для хранилища.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass


def _fmt_ts(ts: float | None) -> str:
    if ts is None:
        return "—"
    import datetime
    return datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


@dataclass
class ScanSession:
    id: int
    created_at: float
    finished_at: float | None
    url: str
    params: list[str]
    os_type: str
    depth: int
    threads: int
    encodings: list[str]
    proxy: str | None
    cookies: dict
    total: int
    done: int
    found_count: int
    errors: int
    status: str  # running / done / stopped / error

    @classmethod
    def from_row(cls, row) -> "ScanSession":
        return cls(
            id=row["id"],
            created_at=row["created_at"],
            finished_at=row["finished_at"],
            url=row["url"],
            params=json.loads(row["params"]),
            os_type=row["os_type"],
            depth=row["depth"],
            threads=row["threads"],
            encodings=json.loads(row["encodings"]),
            proxy=row["proxy"],
            cookies=json.loads(row["cookies"]) if row["cookies"] else {},
            total=row["total"],
            done=row["done"],
            found_count=row["found_count"],
            errors=row["errors"],
            status=row["status"],
        )

    @property
    def created_at_fmt(self) -> str:
        return _fmt_ts(self.created_at)

    @property
    def finished_at_fmt(self) -> str:
        return _fmt_ts(self.finished_at)

    @property
    def elapsed_fmt(self) -> str:
        if self.finished_at:
            sec = self.finished_at - self.created_at
        elif self.status == "running":
            sec = time.time() - self.created_at
        else:
            return "—"
        m, s = divmod(int(sec), 60)
        return f"{m}m {s}s" if m else f"{s}s"

    @property
    def progress_pct(self) -> int:
        return int(self.done / self.total * 100) if self.total else 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "url": self.url,
            "params": self.params,
            "os_type": self.os_type,
            "depth": self.depth,
            "threads": self.threads,
            "encodings": self.encodings,
            "proxy": self.proxy,
            "status": self.status,
            "found_count": self.found_count,
            "total": self.total,
            "done": self.done,
            "errors": self.errors,
            "created_at": self.created_at_fmt,
            "finished_at": self.finished_at_fmt,
        }


@dataclass
class StoredFinding:
    id: int
    session_id: int
    discovered_at: float
    param: str
    target_file: str
    raw_payload: str
    encoded_payload: str
    encoding: str
    technique: str
    matched_pattern: str
    status_code: int
    response_length: int
    baseline_length: int
    size_delta: int
    elapsed_ms: int
    url: str
    notes: str
    method: str = "GET"
    is_wrapper: bool = False
    decoded_content: str = ""

    @classmethod
    def from_row(cls, row) -> "StoredFinding":
        return cls(
            id=row["id"],
            session_id=row["session_id"],
            discovered_at=row["discovered_at"],
            param=row["param"],
            target_file=row["target_file"],
            raw_payload=row["raw_payload"],
            encoded_payload=row["encoded_payload"],
            encoding=row["encoding"],
            technique=row["technique"],
            matched_pattern=row["matched_pattern"],
            status_code=row["status_code"],
            response_length=row["response_length"],
            baseline_length=row["baseline_length"],
            size_delta=row["size_delta"],
            elapsed_ms=row["elapsed_ms"],
            url=row["url"],
            notes=row["notes"] or "",
            method=row["method"] if "method" in row.keys() else "GET",
            is_wrapper=bool(row["is_wrapper"]) if "is_wrapper" in row.keys() else False,
            decoded_content=row["decoded_content"] if "decoded_content" in row.keys() else "",
        )

    @property
    def discovered_at_fmt(self) -> str:
        return _fmt_ts(self.discovered_at)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "param": self.param,
            "target_file": self.target_file,
            "raw_payload": self.raw_payload,
            "encoded_payload": self.encoded_payload,
            "encoding": self.encoding,
            "technique": self.technique,
            "matched_pattern": self.matched_pattern,
            "status_code": self.status_code,
            "response_length": self.response_length,
            "baseline_length": self.baseline_length,
            "size_delta": self.size_delta,
            "elapsed_ms": self.elapsed_ms,
            "url": self.url,
            "notes": self.notes,
            "method": self.method,
            "is_wrapper": self.is_wrapper,
            "decoded_content": self.decoded_content,
            "discovered_at": self.discovered_at_fmt,
        }
